#!/bin/bash

# ============================================================
# RESTORE SCRIPT - Deusizi Sparkle
# ============================================================

set -e

BACKUP_DIR=$(dirname "$0")
PROJECT_PATH="/var/www/izimaid-backend"
DB_NAME="izimaid_db"
DB_USER="izimaid_user"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "========================================="
echo "     🔄 DEUSIZI RESTORE STARTED"
echo "========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}❌ Please run as root (sudo su)${NC}"
    exit 1
fi

echo -e "${GREEN}📦 Step 1: Extracting project files...${NC}"

# Create project directory if not exists
mkdir -p "${PROJECT_PATH}"

# Copy project files
rsync -av "${BACKUP_DIR}/project/" "${PROJECT_PATH}/"

echo -e "${GREEN}✅ Project files restored${NC}"

echo -e "\n${GREEN}📦 Step 2: Restoring .env file...${NC}"
cp "${BACKUP_DIR}/.env" "${PROJECT_PATH}/.env"
echo -e "${GREEN}✅ .env file restored${NC}"

echo -e "\n${GREEN}📦 Step 3: Restoring database...${NC}"

# Restore database
if [ -f "${BACKUP_DIR}/database.backup" ]; then
    echo "Restoring from binary backup..."
    sudo -u postgres pg_restore -d "${DB_NAME}" --clean --if-exists "${BACKUP_DIR}/database.backup"
else
    echo "Restoring from SQL backup..."
    sudo -u postgres psql -d "${DB_NAME}" < "${BACKUP_DIR}/database.sql"
fi

echo -e "${GREEN}✅ Database restored${NC}"

echo -e "\n${GREEN}📦 Step 4: Installing dependencies...${NC}"
cd "${PROJECT_PATH}"
npm install --production
echo -e "${GREEN}✅ Dependencies installed${NC}"

echo -e "\n${GREEN}📦 Step 5: Starting application...${NC}"

# Check if PM2 is installed
if ! command -v pm2 &> /dev/null; then
    echo -e "${YELLOW}⚠️  PM2 not found, installing...${NC}"
    npm install -g pm2
fi

pm2 stop izimaid-api 2>/dev/null || true
pm2 delete izimaid-api 2>/dev/null || true
pm2 start server.js --name 'izimaid-api'
pm2 save

echo -e "${GREEN}✅ Application started${NC}"

echo -e "\n${GREEN}=========================================${NC}"
echo -e "${GREEN}     ✅ RESTORE COMPLETE!${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo "🌐 API URL: https://api.deusizisparkle.com"
echo ""
