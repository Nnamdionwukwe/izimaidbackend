--
-- PostgreSQL database dump
--

\restrict gmG8DUuKwSzJv75wd55sUb5lH2dndhJp4YTzkK1YK8FKDFwE6s3ibgtbcnV939P

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_reviewed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.wallet_transactions DROP CONSTRAINT IF EXISTS wallet_transactions_withdrawal_id_fkey;
ALTER TABLE IF EXISTS ONLY public.wallet_transactions DROP CONSTRAINT IF EXISTS wallet_transactions_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.wallet_transactions DROP CONSTRAINT IF EXISTS wallet_transactions_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_settings DROP CONSTRAINT IF EXISTS user_settings_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_devices DROP CONSTRAINT IF EXISTS user_devices_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.support_ticket_attachments DROP CONSTRAINT IF EXISTS support_ticket_attachments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_deleted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.support_conversations DROP CONSTRAINT IF EXISTS support_conversations_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscription_invoices DROP CONSTRAINT IF EXISTS subscription_invoices_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscription_invoices DROP CONSTRAINT IF EXISTS subscription_invoices_subscription_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sos_alerts DROP CONSTRAINT IF EXISTS sos_alerts_triggered_by_fkey;
ALTER TABLE IF EXISTS ONLY public.sos_alerts DROP CONSTRAINT IF EXISTS sos_alerts_resolved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.sos_alerts DROP CONSTRAINT IF EXISTS sos_alerts_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_reviewer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.push_tokens DROP CONSTRAINT IF EXISTS push_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.promo_codes DROP CONSTRAINT IF EXISTS promo_codes_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.platform_settings DROP CONSTRAINT IF EXISTS platform_settings_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.pin_attempts DROP CONSTRAINT IF EXISTS pin_attempts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_receiver_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_deleted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_wallets DROP CONSTRAINT IF EXISTS maid_wallets_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_tickets DROP CONSTRAINT IF EXISTS maid_support_tickets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_replies DROP CONSTRAINT IF EXISTS maid_support_replies_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_replies DROP CONSTRAINT IF EXISTS maid_support_replies_ticket_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_messages DROP CONSTRAINT IF EXISTS maid_support_messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_messages DROP CONSTRAINT IF EXISTS maid_support_messages_deleted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_messages DROP CONSTRAINT IF EXISTS maid_support_messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_conversations DROP CONSTRAINT IF EXISTS maid_support_conversations_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_profiles DROP CONSTRAINT IF EXISTS maid_profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_payouts DROP CONSTRAINT IF EXISTS maid_payouts_processed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_payouts DROP CONSTRAINT IF EXISTS maid_payouts_payment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_payouts DROP CONSTRAINT IF EXISTS maid_payouts_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_payouts DROP CONSTRAINT IF EXISTS maid_payouts_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_documents DROP CONSTRAINT IF EXISTS maid_documents_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_bank_details DROP CONSTRAINT IF EXISTS maid_bank_details_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maid_availability DROP CONSTRAINT IF EXISTS maid_availability_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.emergency_contacts DROP CONSTRAINT IF EXISTS emergency_contacts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customer_support_tickets DROP CONSTRAINT IF EXISTS customer_support_tickets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customer_support_replies DROP CONSTRAINT IF EXISTS customer_support_replies_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customer_support_replies DROP CONSTRAINT IF EXISTS customer_support_replies_ticket_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS chat_messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS chat_messages_receiver_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS chat_messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS chat_conversations_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_escrow_released_by_fkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_cancelled_by_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.booking_locations DROP CONSTRAINT IF EXISTS booking_locations_maid_id_fkey;
ALTER TABLE IF EXISTS ONLY public.booking_locations DROP CONSTRAINT IF EXISTS booking_locations_booking_id_fkey;
ALTER TABLE IF EXISTS ONLY public.admin_reports DROP CONSTRAINT IF EXISTS admin_reports_generated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.admin_audit_log DROP CONSTRAINT IF EXISTS admin_audit_log_admin_id_fkey;
DROP INDEX IF EXISTS public.idx_withdrawals_status;
DROP INDEX IF EXISTS public.idx_withdrawals_maid;
DROP INDEX IF EXISTS public.idx_wallet_tx_maid;
DROP INDEX IF EXISTS public.idx_users_reset_token;
DROP INDEX IF EXISTS public.idx_users_reset_password_token;
DROP INDEX IF EXISTS public.idx_users_google_id;
DROP INDEX IF EXISTS public.idx_users_facebook_id;
DROP INDEX IF EXISTS public.idx_users_email_verify_token;
DROP INDEX IF EXISTS public.idx_users_auth_provider;
DROP INDEX IF EXISTS public.idx_users_apple_id;
DROP INDEX IF EXISTS public.idx_user_devices_user_id;
DROP INDEX IF EXISTS public.idx_user_devices_last_seen;
DROP INDEX IF EXISTS public.idx_support_ticket_attachments_user_id;
DROP INDEX IF EXISTS public.idx_support_ticket_attachments_ticket_type;
DROP INDEX IF EXISTS public.idx_support_ticket_attachments_ticket_id;
DROP INDEX IF EXISTS public.idx_support_ticket_attachments_created_at;
DROP INDEX IF EXISTS public.idx_support_msg_unread;
DROP INDEX IF EXISTS public.idx_support_msg_sender;
DROP INDEX IF EXISTS public.idx_support_msg_created;
DROP INDEX IF EXISTS public.idx_support_msg_conv_id;
DROP INDEX IF EXISTS public.idx_support_conv_updated;
DROP INDEX IF EXISTS public.idx_support_conv_customer;
DROP INDEX IF EXISTS public.idx_subs_user;
DROP INDEX IF EXISTS public.idx_subs_gateway_stripe;
DROP INDEX IF EXISTS public.idx_subs_gateway_paystack;
DROP INDEX IF EXISTS public.idx_subs_expiry;
DROP INDEX IF EXISTS public.idx_sub_invoices_user;
DROP INDEX IF EXISTS public.idx_sub_invoices_sub;
DROP INDEX IF EXISTS public.idx_sos_alerts_status;
DROP INDEX IF EXISTS public.idx_sos_alerts_booking_id;
DROP INDEX IF EXISTS public.idx_sos_alerts_booking;
DROP INDEX IF EXISTS public.idx_reviews_maid;
DROP INDEX IF EXISTS public.idx_reviews_customer_id;
DROP INDEX IF EXISTS public.idx_push_tokens_user;
DROP INDEX IF EXISTS public.idx_pin_attempts_user;
DROP INDEX IF EXISTS public.idx_payments_paystack_reference;
DROP INDEX IF EXISTS public.idx_notifications_user_id;
DROP INDEX IF EXISTS public.idx_notif_user_unread;
DROP INDEX IF EXISTS public.idx_notif_user_type;
DROP INDEX IF EXISTS public.idx_notif_created;
DROP INDEX IF EXISTS public.idx_messages_deleted_at;
DROP INDEX IF EXISTS public.idx_messages_conversation_id;
DROP INDEX IF EXISTS public.idx_maid_support_tickets_user_id;
DROP INDEX IF EXISTS public.idx_maid_support_tickets_status;
DROP INDEX IF EXISTS public.idx_maid_support_tickets_created_at;
DROP INDEX IF EXISTS public.idx_maid_support_tickets_category;
DROP INDEX IF EXISTS public.idx_maid_support_replies_user_id;
DROP INDEX IF EXISTS public.idx_maid_support_replies_ticket_id;
DROP INDEX IF EXISTS public.idx_maid_support_msg_unread;
DROP INDEX IF EXISTS public.idx_maid_support_msg_sender;
DROP INDEX IF EXISTS public.idx_maid_support_msg_created;
DROP INDEX IF EXISTS public.idx_maid_support_msg_conv_id;
DROP INDEX IF EXISTS public.idx_maid_support_conv_updated;
DROP INDEX IF EXISTS public.idx_maid_support_conv_maid;
DROP INDEX IF EXISTS public.idx_maid_profiles_years_exp;
DROP INDEX IF EXISTS public.idx_maid_profiles_rating;
DROP INDEX IF EXISTS public.idx_maid_profiles_location;
DROP INDEX IF EXISTS public.idx_maid_profiles_is_available;
DROP INDEX IF EXISTS public.idx_maid_payouts_maid;
DROP INDEX IF EXISTS public.idx_maid_payouts_booking;
DROP INDEX IF EXISTS public.idx_emergency_contacts_user;
DROP INDEX IF EXISTS public.idx_customer_support_tickets_user_id;
DROP INDEX IF EXISTS public.idx_customer_support_tickets_status;
DROP INDEX IF EXISTS public.idx_customer_support_replies_ticket_id;
DROP INDEX IF EXISTS public.idx_conversations_type;
DROP INDEX IF EXISTS public.idx_conversations_maid_id;
DROP INDEX IF EXISTS public.idx_conversations_customer_id;
DROP INDEX IF EXISTS public.idx_conversations_booking_id;
DROP INDEX IF EXISTS public.idx_chat_messages_sender_id;
DROP INDEX IF EXISTS public.idx_chat_messages_receiver_id;
DROP INDEX IF EXISTS public.idx_chat_messages_is_read;
DROP INDEX IF EXISTS public.idx_chat_messages_conversation_id;
DROP INDEX IF EXISTS public.idx_chat_conversations_maid_id;
DROP INDEX IF EXISTS public.idx_chat_conversations_customer_id;
DROP INDEX IF EXISTS public.idx_chat_conversations_booking_id;
DROP INDEX IF EXISTS public.idx_bookings_status;
DROP INDEX IF EXISTS public.idx_bookings_service_date;
DROP INDEX IF EXISTS public.idx_bookings_maid_id;
DROP INDEX IF EXISTS public.idx_bookings_maid;
DROP INDEX IF EXISTS public.idx_bookings_escrow_status;
DROP INDEX IF EXISTS public.idx_bookings_customer_id;
DROP INDEX IF EXISTS public.idx_bookings_customer;
DROP INDEX IF EXISTS public.idx_booking_locations_recorded_at;
DROP INDEX IF EXISTS public.idx_booking_locations_booking_id;
DROP INDEX IF EXISTS public.idx_booking_locations_booking;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_created;
DROP INDEX IF EXISTS public.idx_audit_admin;
ALTER TABLE IF EXISTS ONLY public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_pkey;
ALTER TABLE IF EXISTS ONLY public.wallet_transactions DROP CONSTRAINT IF EXISTS wallet_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_settings DROP CONSTRAINT IF EXISTS user_settings_user_id_key;
ALTER TABLE IF EXISTS ONLY public.user_settings DROP CONSTRAINT IF EXISTS user_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.user_devices DROP CONSTRAINT IF EXISTS user_devices_user_id_device_hash_key;
ALTER TABLE IF EXISTS ONLY public.user_devices DROP CONSTRAINT IF EXISTS user_devices_pkey;
ALTER TABLE IF EXISTS ONLY public.supported_languages DROP CONSTRAINT IF EXISTS supported_languages_pkey;
ALTER TABLE IF EXISTS ONLY public.supported_currencies DROP CONSTRAINT IF EXISTS supported_currencies_pkey;
ALTER TABLE IF EXISTS ONLY public.support_ticket_attachments DROP CONSTRAINT IF EXISTS support_ticket_attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.support_conversations DROP CONSTRAINT IF EXISTS support_conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.support_conversations DROP CONSTRAINT IF EXISTS support_conversations_customer_id_key;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_user_id_status_key;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_plans DROP CONSTRAINT IF EXISTS subscription_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_invoices DROP CONSTRAINT IF EXISTS subscription_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.sos_alerts DROP CONSTRAINT IF EXISTS sos_alerts_pkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_pkey;
ALTER TABLE IF EXISTS ONLY public.push_tokens DROP CONSTRAINT IF EXISTS push_tokens_user_id_token_key;
ALTER TABLE IF EXISTS ONLY public.push_tokens DROP CONSTRAINT IF EXISTS push_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.promo_codes DROP CONSTRAINT IF EXISTS promo_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.promo_codes DROP CONSTRAINT IF EXISTS promo_codes_code_key;
ALTER TABLE IF EXISTS ONLY public.platform_settings DROP CONSTRAINT IF EXISTS platform_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.pin_attempts DROP CONSTRAINT IF EXISTS pin_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_user_id_key;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.ng_banks DROP CONSTRAINT IF EXISTS ng_banks_pkey;
ALTER TABLE IF EXISTS ONLY public.ng_banks DROP CONSTRAINT IF EXISTS ng_banks_code_key;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_wallets DROP CONSTRAINT IF EXISTS maid_wallets_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_wallets DROP CONSTRAINT IF EXISTS maid_wallets_maid_id_key;
ALTER TABLE IF EXISTS ONLY public.maid_wallets DROP CONSTRAINT IF EXISTS maid_wallets_maid_id_currency_key;
ALTER TABLE IF EXISTS ONLY public.maid_support_tickets DROP CONSTRAINT IF EXISTS maid_support_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_replies DROP CONSTRAINT IF EXISTS maid_support_replies_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_messages DROP CONSTRAINT IF EXISTS maid_support_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_conversations DROP CONSTRAINT IF EXISTS maid_support_conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_support_conversations DROP CONSTRAINT IF EXISTS maid_support_conversations_maid_id_key;
ALTER TABLE IF EXISTS ONLY public.maid_profiles DROP CONSTRAINT IF EXISTS maid_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_payouts DROP CONSTRAINT IF EXISTS maid_payouts_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_documents DROP CONSTRAINT IF EXISTS maid_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_bank_details DROP CONSTRAINT IF EXISTS maid_bank_details_pkey;
ALTER TABLE IF EXISTS ONLY public.maid_bank_details DROP CONSTRAINT IF EXISTS maid_bank_details_maid_id_key;
ALTER TABLE IF EXISTS ONLY public.maid_availability DROP CONSTRAINT IF EXISTS maid_availability_pkey;
ALTER TABLE IF EXISTS ONLY public.emergency_contacts DROP CONSTRAINT IF EXISTS emergency_contacts_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_support_tickets DROP CONSTRAINT IF EXISTS customer_support_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_support_replies DROP CONSTRAINT IF EXISTS customer_support_replies_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS chat_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS chat_conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_pkey;
ALTER TABLE IF EXISTS ONLY public.booking_locations DROP CONSTRAINT IF EXISTS booking_locations_pkey;
ALTER TABLE IF EXISTS ONLY public.admin_reports DROP CONSTRAINT IF EXISTS admin_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.admin_audit_log DROP CONSTRAINT IF EXISTS admin_audit_log_pkey;
DROP TABLE IF EXISTS public.withdrawals;
DROP TABLE IF EXISTS public.wallet_transactions;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_settings;
DROP TABLE IF EXISTS public.user_devices;
DROP TABLE IF EXISTS public.supported_languages;
DROP TABLE IF EXISTS public.supported_currencies;
DROP TABLE IF EXISTS public.support_ticket_attachments;
DROP TABLE IF EXISTS public.support_messages;
DROP TABLE IF EXISTS public.support_conversations;
DROP TABLE IF EXISTS public.subscriptions;
DROP TABLE IF EXISTS public.subscription_plans;
DROP TABLE IF EXISTS public.subscription_invoices;
DROP TABLE IF EXISTS public.sos_alerts;
DROP TABLE IF EXISTS public.reviews;
DROP TABLE IF EXISTS public.push_tokens;
DROP TABLE IF EXISTS public.promo_codes;
DROP TABLE IF EXISTS public.platform_settings;
DROP TABLE IF EXISTS public.pin_attempts;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.notification_preferences;
DROP TABLE IF EXISTS public.ng_banks;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.maid_wallets;
DROP TABLE IF EXISTS public.maid_support_tickets;
DROP TABLE IF EXISTS public.maid_support_replies;
DROP TABLE IF EXISTS public.maid_support_messages;
DROP TABLE IF EXISTS public.maid_support_conversations;
DROP TABLE IF EXISTS public.maid_profiles;
DROP TABLE IF EXISTS public.maid_payouts;
DROP TABLE IF EXISTS public.maid_documents;
DROP TABLE IF EXISTS public.maid_bank_details;
DROP TABLE IF EXISTS public.maid_availability;
DROP TABLE IF EXISTS public.emergency_contacts;
DROP TABLE IF EXISTS public.customer_support_tickets;
DROP TABLE IF EXISTS public.customer_support_replies;
DROP TABLE IF EXISTS public.conversations;
DROP TABLE IF EXISTS public.chat_messages;
DROP TABLE IF EXISTS public.bookings;
DROP TABLE IF EXISTS public.booking_locations;
DROP TABLE IF EXISTS public.admin_reports;
DROP TABLE IF EXISTS public.admin_audit_log;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid,
    before_data jsonb,
    after_data jsonb,
    ip_address text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: admin_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    period text NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    generated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: booking_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_locations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid NOT NULL,
    maid_id uuid NOT NULL,
    lat numeric(9,6) NOT NULL,
    lng numeric(9,6) NOT NULL,
    accuracy numeric(8,2),
    recorded_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id uuid,
    maid_id uuid,
    service_type character varying(255),
    booking_date timestamp with time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    total_amount numeric(12,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_recurring boolean DEFAULT false,
    recurrence_rule text,
    cancelled_by text,
    cancelled_reason text,
    cancelled_at timestamp with time zone,
    checkin_at timestamp with time zone,
    checkout_at timestamp with time zone,
    checkin_lat numeric(9,6),
    checkin_lng numeric(9,6),
    rate_type text DEFAULT 'hourly'::text NOT NULL,
    video_call_room text,
    video_call_token text,
    video_call_status text DEFAULT 'none'::text,
    maid_accepted_at timestamp with time zone,
    live_tracking_on boolean DEFAULT false NOT NULL,
    service_date timestamp with time zone,
    duration_hours integer DEFAULT 1,
    duration_qty integer DEFAULT 1,
    address text,
    notes text,
    checkout_lat numeric(10,7),
    checkout_lng numeric(10,7),
    video_call_channel text,
    video_call_started_at timestamp with time zone,
    cancelled_by_user_id uuid,
    rescheduled_at timestamp with time zone,
    escrow_status character varying(50) DEFAULT 'pending_release'::character varying,
    escrow_released_at timestamp with time zone,
    escrow_released_by uuid
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid,
    sender_id uuid,
    receiver_id uuid,
    message text,
    message_type character varying(50) DEFAULT 'text'::character varying,
    is_read boolean DEFAULT false,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid,
    customer_id uuid,
    maid_id uuid,
    unread_count integer DEFAULT 0,
    last_message text,
    last_message_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    unread_customer integer DEFAULT 0,
    unread_maid integer DEFAULT 0,
    deleted_by_customer boolean DEFAULT false,
    deleted_by_maid boolean DEFAULT false,
    deleted_at_customer timestamp with time zone,
    deleted_at_maid timestamp with time zone,
    type character varying(50) DEFAULT 'booking'::character varying
);


--
-- Name: customer_support_replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_support_replies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid,
    user_id uuid,
    message text NOT NULL,
    is_internal boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: customer_support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_support_tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    subject text NOT NULL,
    message text NOT NULL,
    category text NOT NULL,
    priority text DEFAULT 'normal'::text,
    status text DEFAULT 'open'::text,
    admin_notes text,
    attachment_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: emergency_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.emergency_contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    relationship text DEFAULT 'other'::text NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maid_availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_availability (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: maid_bank_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_bank_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    bank_name text NOT NULL,
    account_number text NOT NULL,
    account_name text NOT NULL,
    bank_code text,
    country text DEFAULT 'NG'::text NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    stripe_account_id text,
    verified boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maid_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    doc_type text NOT NULL,
    doc_url text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    admin_notes text,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp with time zone
);


--
-- Name: maid_payouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_payouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    booking_id uuid NOT NULL,
    payment_id uuid NOT NULL,
    amount numeric NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    gateway text DEFAULT 'manual'::text NOT NULL,
    payout_ref text,
    bank_name text,
    account_number text,
    account_name text,
    stripe_transfer_id text,
    notes text,
    processed_by uuid,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: maid_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    full_name character varying(255),
    email character varying(255),
    phone character varying(50),
    city character varying(100),
    state character varying(50),
    country character varying(50),
    postal_code character varying(20),
    experience_years integer DEFAULT 0,
    skills text[],
    hourly_rate numeric(10,2),
    is_verified boolean DEFAULT false,
    rating numeric(3,2) DEFAULT 0,
    total_reviews integer DEFAULT 0,
    bio text,
    availability text[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    latitude numeric(9,6),
    longitude numeric(9,6),
    currency text DEFAULT 'NGN'::text,
    stripe_account_id text,
    id_verified boolean DEFAULT false,
    background_checked boolean DEFAULT false,
    languages text[] DEFAULT '{}'::text[],
    max_distance_km integer DEFAULT 20,
    rate_hourly numeric,
    rate_daily numeric,
    rate_weekly numeric,
    rate_monthly numeric,
    rate_custom jsonb,
    pricing_note text,
    location text,
    years_exp integer DEFAULT 0,
    services text[],
    is_available boolean DEFAULT true,
    completed_bookings integer DEFAULT 0,
    verification_status text DEFAULT 'pending'::text,
    rejection_reason text,
    avatar_url text,
    cover_image text,
    gallery_images text[],
    documents jsonb,
    certifications text[],
    availability_schedule jsonb,
    response_time integer DEFAULT 0,
    last_active timestamp with time zone
);


--
-- Name: maid_support_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_support_conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    unread_maid integer DEFAULT 0 NOT NULL,
    unread_admin integer DEFAULT 0 NOT NULL,
    deleted_by_maid boolean DEFAULT false NOT NULL,
    deleted_at_maid timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: maid_support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_support_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    content text,
    message_type character varying(10) DEFAULT 'text'::character varying NOT NULL,
    media_url text,
    media_type character varying(10),
    is_read boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_maid_support_message_content CHECK (((((message_type)::text = 'text'::text) AND (content IS NOT NULL)) OR (((message_type)::text <> 'text'::text) AND (media_url IS NOT NULL))))
);


--
-- Name: maid_support_replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_support_replies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid NOT NULL,
    user_id uuid NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: maid_support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_support_tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    category character varying(50) NOT NULL,
    priority character varying(20) DEFAULT 'normal'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    admin_notes text,
    attachment_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_priority CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'normal'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: maid_wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maid_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    available numeric DEFAULT 0 NOT NULL,
    pending numeric DEFAULT 0 NOT NULL,
    total_earned numeric DEFAULT 0 NOT NULL,
    total_withdrawn numeric DEFAULT 0 NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    available_balance numeric(15,2) DEFAULT 0,
    pending_balance numeric(15,2) DEFAULT 0
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sender_id uuid,
    receiver_id uuid,
    content text,
    message_type character varying(50) DEFAULT 'text'::character varying,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    media_url text,
    media_type character varying(50),
    read_at timestamp with time zone,
    conversation_id uuid
);


--
-- Name: ng_banks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ng_banks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    type text DEFAULT 'bank'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    supports_paystack boolean DEFAULT true NOT NULL
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    inapp_bookings boolean DEFAULT true NOT NULL,
    inapp_payments boolean DEFAULT true NOT NULL,
    inapp_messages boolean DEFAULT true NOT NULL,
    inapp_reviews boolean DEFAULT true NOT NULL,
    inapp_withdrawals boolean DEFAULT true NOT NULL,
    inapp_support boolean DEFAULT true NOT NULL,
    inapp_system boolean DEFAULT true NOT NULL,
    inapp_promotions boolean DEFAULT true NOT NULL,
    email_bookings boolean DEFAULT true NOT NULL,
    email_payments boolean DEFAULT true NOT NULL,
    email_messages boolean DEFAULT false NOT NULL,
    email_reviews boolean DEFAULT true NOT NULL,
    email_withdrawals boolean DEFAULT true NOT NULL,
    email_support boolean DEFAULT true NOT NULL,
    email_system boolean DEFAULT true NOT NULL,
    email_promotions boolean DEFAULT false NOT NULL,
    push_bookings boolean DEFAULT true NOT NULL,
    push_payments boolean DEFAULT true NOT NULL,
    push_messages boolean DEFAULT true NOT NULL,
    push_reviews boolean DEFAULT true NOT NULL,
    push_withdrawals boolean DEFAULT true NOT NULL,
    push_support boolean DEFAULT true NOT NULL,
    push_system boolean DEFAULT true NOT NULL,
    push_promotions boolean DEFAULT false NOT NULL,
    sms_bookings boolean DEFAULT false NOT NULL,
    sms_payments boolean DEFAULT false NOT NULL,
    sms_security boolean DEFAULT true NOT NULL,
    quiet_hours_enabled boolean DEFAULT false NOT NULL,
    quiet_hours_start time without time zone DEFAULT '22:00:00'::time without time zone,
    quiet_hours_end time without time zone DEFAULT '08:00:00'::time without time zone,
    quiet_hours_timezone text DEFAULT 'Africa/Lagos'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    channel text DEFAULT 'in_app'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    action_url text,
    image_url text,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid,
    user_id uuid,
    amount numeric(12,2),
    currency character varying(10) DEFAULT 'NGN'::character varying,
    payment_method character varying(50),
    status character varying(50) DEFAULT 'pending'::character varying,
    reference character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    stripe_payment_id text,
    stripe_session_id text,
    gateway text DEFAULT 'paystack'::text,
    platform_fee numeric DEFAULT 0,
    maid_payout numeric DEFAULT 0,
    payout_status text DEFAULT 'pending'::text,
    payout_at timestamp with time zone,
    bank_transfer_ref text,
    bank_transfer_proof text,
    bank_transfer_status text DEFAULT 'pending'::text,
    crypto_charge_id text,
    crypto_charge_code text,
    crypto_currency text,
    crypto_amount numeric,
    crypto_address text,
    crypto_expires_at timestamp with time zone,
    notes text,
    paid_at timestamp with time zone,
    customer_id uuid,
    crypto_tx_hash text,
    crypto_proof_url text,
    crypto_amount_sent numeric(15,2),
    crypto_status text DEFAULT 'pending'::text,
    paystack_reference text,
    paystack_access_code text
);


--
-- Name: pin_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pin_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    success boolean NOT NULL,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    description text,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    description text,
    discount_type text DEFAULT 'percent'::text NOT NULL,
    discount_value numeric NOT NULL,
    currency text,
    max_uses integer,
    uses_count integer DEFAULT 0 NOT NULL,
    min_plan text,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_until timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: push_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    platform text DEFAULT 'web'::text NOT NULL,
    device_id text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid,
    reviewer_id uuid,
    maid_id uuid,
    rating integer NOT NULL,
    comment text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_id uuid,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: sos_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sos_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid NOT NULL,
    triggered_by uuid NOT NULL,
    lat numeric(9,6),
    lng numeric(9,6),
    address text,
    message text,
    status text DEFAULT 'active'::text NOT NULL,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    subscription_id uuid NOT NULL,
    user_id uuid NOT NULL,
    amount numeric NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    gateway text,
    gateway_ref text,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    paid_at timestamp with time zone,
    failure_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    display_name text NOT NULL,
    description text,
    target_role text DEFAULT 'customer'::text NOT NULL,
    plan_type text DEFAULT 'recurring'::text NOT NULL,
    "interval" text DEFAULT 'monthly'::text,
    prices jsonb DEFAULT '{}'::jsonb NOT NULL,
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    bookings_per_month integer,
    discount_percent integer DEFAULT 0,
    priority_matching boolean DEFAULT false NOT NULL,
    dedicated_support boolean DEFAULT false NOT NULL,
    badge text,
    trial_days integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    stripe_price_ids jsonb DEFAULT '{}'::jsonb,
    paystack_plan_codes jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    "interval" text DEFAULT 'monthly'::text NOT NULL,
    current_period_start timestamp with time zone DEFAULT now() NOT NULL,
    current_period_end timestamp with time zone NOT NULL,
    trial_start timestamp with time zone,
    trial_end timestamp with time zone,
    cancelled_at timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    cancellation_reason text,
    paused_at timestamp with time zone,
    resumed_at timestamp with time zone,
    gateway text DEFAULT 'manual'::text,
    paystack_sub_code text,
    paystack_email_token text,
    stripe_sub_id text,
    stripe_customer_id text,
    promo_code text,
    discount_percent integer DEFAULT 0,
    bookings_used integer DEFAULT 0 NOT NULL,
    auto_renew boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id uuid NOT NULL,
    unread_customer integer DEFAULT 0 NOT NULL,
    unread_admin integer DEFAULT 0 NOT NULL,
    deleted_by_customer boolean DEFAULT false NOT NULL,
    deleted_at_customer timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    content text,
    message_type character varying(10) DEFAULT 'text'::character varying NOT NULL,
    media_url text,
    media_type character varying(10),
    is_read boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_support_message_content CHECK (((((message_type)::text = 'text'::text) AND (content IS NOT NULL)) OR (((message_type)::text <> 'text'::text) AND (media_url IS NOT NULL))))
);


--
-- Name: support_ticket_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_ticket_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid NOT NULL,
    ticket_type character varying(20) NOT NULL,
    user_id uuid NOT NULL,
    media_url character varying(1000) NOT NULL,
    media_type character varying(20) NOT NULL,
    file_name character varying(255),
    file_size integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_media_type CHECK (((media_type)::text = ANY ((ARRAY['image'::character varying, 'video'::character varying])::text[]))),
    CONSTRAINT valid_ticket_type CHECK (((ticket_type)::text = ANY ((ARRAY['customer'::character varying, 'maid'::character varying])::text[])))
);


--
-- Name: supported_currencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supported_currencies (
    code text NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    paystack_supported boolean DEFAULT false NOT NULL,
    stripe_supported boolean DEFAULT false NOT NULL
);


--
-- Name: supported_languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supported_languages (
    code text NOT NULL,
    name text NOT NULL,
    native_name text NOT NULL,
    rtl boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: user_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    device_hash text NOT NULL,
    user_agent text,
    ip_address text,
    last_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    theme text DEFAULT 'system'::text NOT NULL,
    notifications_email boolean DEFAULT true NOT NULL,
    notifications_push boolean DEFAULT true NOT NULL,
    notifications_sms boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    full_name character varying(255),
    phone character varying(50),
    role character varying(50) DEFAULT 'customer'::character varying,
    is_verified boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    country text DEFAULT 'NG'::text,
    language text DEFAULT 'en'::text,
    timezone text DEFAULT 'Africa/Lagos'::text,
    last_seen_at timestamp with time zone,
    admin_notes text,
    flagged boolean DEFAULT false NOT NULL,
    flag_reason text,
    banned_at timestamp with time zone,
    ban_reason text,
    subscription_plan text DEFAULT 'free'::text,
    subscription_badge text,
    transaction_pin_hash text,
    pin_set_at timestamp with time zone,
    pin_failed_attempts integer DEFAULT 0 NOT NULL,
    pin_locked_until timestamp with time zone,
    google_id text,
    google_email text,
    google_name text,
    google_picture text,
    facebook_id text,
    facebook_email text,
    facebook_name text,
    apple_id text,
    apple_email text,
    apple_name text,
    reset_password_token text,
    reset_password_expires timestamp with time zone,
    email_verified boolean DEFAULT false,
    email_verification_token text,
    email_verification_expires timestamp with time zone,
    name character varying(255),
    avatar text,
    auth_provider character varying(50) DEFAULT 'email'::character varying,
    auth_provider_id text,
    email_verify_token text,
    email_verify_expires timestamp with time zone,
    reset_token text,
    reset_token_expires timestamp with time zone
);


--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    type text NOT NULL,
    amount numeric NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    source text NOT NULL,
    source_id uuid,
    balance_before numeric DEFAULT 0 NOT NULL,
    balance_after numeric DEFAULT 0 NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    booking_id uuid,
    reference text,
    withdrawal_id uuid
);


--
-- Name: withdrawals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.withdrawals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    maid_id uuid NOT NULL,
    amount numeric NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    method text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    bank_name text,
    account_number text,
    account_name text,
    bank_code text,
    bank_country text,
    swift_code text,
    iban text,
    bank_address text,
    mobile_provider text,
    mobile_number text,
    mobile_country text,
    crypto_currency text,
    crypto_address text,
    crypto_network text,
    paypal_email text,
    wise_email text,
    wise_account_id text,
    flw_reference text,
    fee numeric DEFAULT 0 NOT NULL,
    net_amount numeric DEFAULT 0 NOT NULL,
    gateway_ref text,
    gateway_response jsonb,
    notes text,
    failure_reason text,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_id, action, entity_type, entity_id, before_data, after_data, ip_address, notes, created_at) FROM stdin;
\.


--
-- Data for Name: admin_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_reports (id, type, period, date_from, date_to, data, generated_by, created_at) FROM stdin;
\.


--
-- Data for Name: booking_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_locations (id, booking_id, maid_id, lat, lng, accuracy, recorded_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, customer_id, maid_id, service_type, booking_date, status, total_amount, created_at, updated_at, is_recurring, recurrence_rule, cancelled_by, cancelled_reason, cancelled_at, checkin_at, checkout_at, checkin_lat, checkin_lng, rate_type, video_call_room, video_call_token, video_call_status, maid_accepted_at, live_tracking_on, service_date, duration_hours, duration_qty, address, notes, checkout_lat, checkout_lng, video_call_channel, video_call_started_at, cancelled_by_user_id, rescheduled_at, escrow_status, escrow_released_at, escrow_released_by) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, conversation_id, sender_id, receiver_id, message, message_type, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, booking_id, customer_id, maid_id, unread_count, last_message, last_message_at, created_at, updated_at, unread_customer, unread_maid, deleted_by_customer, deleted_by_maid, deleted_at_customer, deleted_at_maid, type) FROM stdin;
82d5a0de-9baa-4b8e-9e61-1bb3cc23af23	\N	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	c98edd27-0efb-4ae1-acd5-f4f94c297177	0	\N	2026-09-05 23:08:55.35574+00	2026-09-05 23:08:55.35574+00	2026-09-05 23:10:57.435354+00	0	3	f	f	\N	\N	inquiry
\.


--
-- Data for Name: customer_support_replies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_support_replies (id, ticket_id, user_id, message, is_internal, created_at) FROM stdin;
\.


--
-- Data for Name: customer_support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_support_tickets (id, user_id, subject, message, category, priority, status, admin_notes, attachment_count, created_at, updated_at) FROM stdin;
17ff1fa6-0ddb-4eca-8103-873b3e1498a6	c98edd27-0efb-4ae1-acd5-f4f94c297177	Test Ticket from API	This is a test support ticket created via curl	general	normal	open	\N	0	2026-09-06 16:37:43.666195+00	2026-09-06 16:37:43.666195+00
270e99dc-60fa-4435-a265-896cf494cc5c	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	febverv	evervevev	technical	normal	open	\N	0	2026-09-06 16:38:21.13193+00	2026-09-06 16:38:21.13193+00
\.


--
-- Data for Name: emergency_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.emergency_contacts (id, user_id, name, phone, relationship, is_primary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maid_availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_availability (id, maid_id, day_of_week, start_time, end_time, is_active) FROM stdin;
f4a777c4-d082-4a36-8d94-491f59972ec9	c98edd27-0efb-4ae1-acd5-f4f94c297177	0	09:00:00	17:00:00	t
4801da5c-6752-4bc1-a6ce-78cbd90c8d01	c98edd27-0efb-4ae1-acd5-f4f94c297177	1	09:00:00	17:00:00	t
\.


--
-- Data for Name: maid_bank_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_bank_details (id, maid_id, bank_name, account_number, account_name, bank_code, country, currency, stripe_account_id, verified, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maid_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_documents (id, maid_id, doc_type, doc_url, status, admin_notes, submitted_at, reviewed_at) FROM stdin;
\.


--
-- Data for Name: maid_payouts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_payouts (id, maid_id, booking_id, payment_id, amount, currency, status, gateway, payout_ref, bank_name, account_number, account_name, stripe_transfer_id, notes, processed_by, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: maid_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_profiles (id, user_id, full_name, email, phone, city, state, country, postal_code, experience_years, skills, hourly_rate, is_verified, rating, total_reviews, bio, availability, created_at, updated_at, latitude, longitude, currency, stripe_account_id, id_verified, background_checked, languages, max_distance_km, rate_hourly, rate_daily, rate_weekly, rate_monthly, rate_custom, pricing_note, location, years_exp, services, is_available, completed_bookings, verification_status, rejection_reason, avatar_url, cover_image, gallery_images, documents, certifications, availability_schedule, response_time, last_active) FROM stdin;
20d063b3-c664-4002-afd5-aa34dc3ef173	c98edd27-0efb-4ae1-acd5-f4f94c297177	\N	\N	\N	\N	\N	\N	\N	0	\N	10000.00	f	0.00	0	Welcome 	\N	2026-09-05 22:54:29.48184+00	2026-09-05 22:57:57.01877+00	9.098681	7.475710	NGN	\N	f	f	{}	20	10000	50000	150000	250000	{"Custom Home Cleaning": 800000}	Always online chat	Mabushipe, Federal Capital Territory, Nigeria	5	{Cleaning,Electricians,Housekeepers,"Facility Management"}	t	0	pending	\N	\N	\N	\N	\N	\N	\N	0	\N
\.


--
-- Data for Name: maid_support_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_support_conversations (id, maid_id, unread_maid, unread_admin, deleted_by_maid, deleted_at_maid, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maid_support_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_support_messages (id, conversation_id, sender_id, content, message_type, media_url, media_type, is_read, deleted_at, deleted_by, created_at) FROM stdin;
\.


--
-- Data for Name: maid_support_replies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_support_replies (id, ticket_id, user_id, message, created_at) FROM stdin;
\.


--
-- Data for Name: maid_support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_support_tickets (id, user_id, subject, message, category, priority, status, admin_notes, attachment_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: maid_wallets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maid_wallets (id, maid_id, available, pending, total_earned, total_withdrawn, currency, updated_at, available_balance, pending_balance) FROM stdin;
eb0afda5-aa4f-41fc-a447-23c787958e30	c98edd27-0efb-4ae1-acd5-f4f94c297177	0	5000.00	30000.00	5000.00	NGN	2026-09-05 23:19:01.52953+00	25000.00	5000.00
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, sender_id, receiver_id, content, message_type, is_read, created_at, deleted_at, deleted_by, media_url, media_type, read_at, conversation_id) FROM stdin;
744a2b78-e310-4847-8dfc-81e49468f6be	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	\N	hi	text	f	2026-09-05 23:09:57.523826+00	\N	\N	\N	\N	\N	82d5a0de-9baa-4b8e-9e61-1bb3cc23af23
43dfa5aa-bdb3-43ea-b0f8-413f1d22b0e2	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	\N	Hello	text	f	2026-09-05 23:10:36.965255+00	\N	\N	\N	\N	\N	82d5a0de-9baa-4b8e-9e61-1bb3cc23af23
c6a8dcb1-e671-4cd6-a7ec-397013c3a899	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	\N	really	text	f	2026-09-05 23:10:57.43392+00	\N	\N	\N	\N	\N	82d5a0de-9baa-4b8e-9e61-1bb3cc23af23
\.


--
-- Data for Name: ng_banks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ng_banks (id, name, code, type, is_active, supports_paystack) FROM stdin;
a8e9e00e-25f1-4fd4-8a39-13f8dd69f550	Access Bank	044	bank	t	t
fb9736c3-d28c-4b1e-802d-c64205a52683	Citibank Nigeria	023	bank	t	t
5f274281-8af2-41fc-a44d-2a7e7aebeced	Ecobank Nigeria	050	bank	t	t
80cadf28-3e3e-45fa-875f-6fc42291e951	Fidelity Bank	070	bank	t	t
05ce05ec-0325-4c0b-b9dd-defe3fe2bd56	First Bank of Nigeria	011	bank	t	t
c579c698-8ae2-4571-b47f-bd1ca009c065	First City Monument Bank	214	bank	t	t
09e3e08e-5eb6-4ce7-8123-962675b35f4b	Guaranty Trust Bank	058	bank	t	t
260afd9b-df40-4d4e-9376-f6cf9081dc17	Heritage Bank	030	bank	t	t
79d3defc-a101-4aff-b731-f4d769470f3d	Keystone Bank	082	bank	t	t
9de0b539-5d3d-42b9-ab6e-88c7c4469069	Polaris Bank	076	bank	t	t
6f322ee7-9d31-47c0-9fdf-00304f7ccb76	Stanbic IBTC Bank	221	bank	t	t
d40f4eb1-3749-4c41-97e1-0ae65cdd583f	Standard Chartered Bank	068	bank	t	t
e1a0b930-d6e6-42c6-8e56-6735954ab479	Sterling Bank	232	bank	t	t
ac280008-a7d2-4c51-a52f-b6477ef493e8	Union Bank of Nigeria	032	bank	t	t
daa560f9-4b2d-4d01-8ece-b33d04a05de9	United Bank for Africa	033	bank	t	t
336b700b-5345-4a55-ae11-8e04a109f38e	Unity Bank	215	bank	t	t
d7ae8d2e-015a-4164-8aef-bb37f0d64bb8	Wema Bank	035	bank	t	t
0785726c-c88c-4c1c-8d8d-50e5ccbf9602	Zenith Bank	057	bank	t	t
586887c2-b6ac-459c-aac1-d0b7013082a8	Jaiz Bank	301	bank	t	t
a69d92a9-20e6-461f-8154-73b2d36b29cd	Taj Bank	302	bank	t	t
77d30870-796f-4f55-a084-f400e3fc8b38	Titan Trust Bank	102	bank	t	t
ab89d807-917d-4ada-aa9a-fcd83d819464	Globus Bank	103	bank	t	t
f98a7107-3236-440d-b66d-edd38bdafb7d	Lotus Bank	303	bank	t	t
6cba74c0-a7ff-47d7-afb5-082db7238f72	Premium Trust Bank	105	bank	t	t
7eeb63d9-126a-4275-8527-53dc28cc1d38	OPay	100004	fintech	t	t
8d1dc104-e169-42bd-b5ce-3f564aa61d9b	Moniepoint MFB	50515	fintech	t	t
6d5688dd-9621-4984-b261-6a8febf52547	Kuda Bank	50211	fintech	t	t
b9a05f6f-1991-4fbf-b200-e62990d3721f	PalmPay	100033	fintech	t	t
128c39df-94df-4ed0-af48-5cc6dee8a1bf	Carbon (One Finance)	565	fintech	t	t
29ef8b11-8b2c-4da2-a4eb-2f19e045b676	Fairmoney MFB	51318	fintech	t	t
1dcc2c8b-cb0a-414f-9596-9a9208ce9f01	VFD MFB	566	fintech	t	t
806fe365-1181-4bf2-ae60-7f45885af8be	ALAT by Wema	035A	fintech	t	t
b87220a7-cbdf-4b47-8513-cba92713831e	Sparkle MFB	51310	fintech	t	t
4f80ee57-aaea-417e-b431-f202c19e147b	Rubies MFB	125	fintech	t	t
c110f554-ef70-498b-b5ca-f75d51dc326f	Mint MFB (Mintyn)	50304	fintech	t	t
7df7cfee-8d22-4638-9497-e5ced316ca40	Brass MFB	50615	fintech	t	t
8ca86277-db16-4277-91ab-2bbfdcdffc49	Accion MFB	602	mfb	t	t
49cf5086-1b43-487a-874a-8c0758f93455	Lapo MFB	90325	mfb	t	t
3700704f-39a3-4c47-ad7b-c44989eb5690	AB MFB	070010	mfb	t	t
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_preferences (id, user_id, inapp_bookings, inapp_payments, inapp_messages, inapp_reviews, inapp_withdrawals, inapp_support, inapp_system, inapp_promotions, email_bookings, email_payments, email_messages, email_reviews, email_withdrawals, email_support, email_system, email_promotions, push_bookings, push_payments, push_messages, push_reviews, push_withdrawals, push_support, push_system, push_promotions, sms_bookings, sms_payments, sms_security, quiet_hours_enabled, quiet_hours_start, quiet_hours_end, quiet_hours_timezone, created_at, updated_at) FROM stdin;
37b66af1-8448-44a4-b77b-5ab99dcdbac8	c98edd27-0efb-4ae1-acd5-f4f94c297177	t	t	t	t	t	t	t	t	t	t	f	t	t	t	t	f	t	t	t	t	t	t	t	f	f	f	t	f	22:00:00	08:00:00	Africa/Lagos	2026-09-05 23:09:57.530283+00	2026-09-05 23:09:57.530283+00
35053363-091a-48f3-a3b8-e7bd6d6aa79e	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	t	t	t	t	t	t	t	t	t	t	f	t	t	t	t	f	t	t	t	t	t	t	t	f	f	f	t	f	22:00:00	08:00:00	Africa/Lagos	2026-09-05 23:14:43.229521+00	2026-09-05 23:14:43.229521+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, type, title, body, data, is_read, read_at, channel, priority, action_url, image_url, expires_at, created_at) FROM stdin;
3d2ffda5-2cd2-495f-9d99-2128366aae28	c98edd27-0efb-4ae1-acd5-f4f94c297177	new_message	New message from Nnamdi Onwukwe	hi	{"booking_id": null}	f	\N	in_app	normal	/bookings/null	\N	\N	2026-09-05 23:09:57.533592+00
e3ea03d4-4b23-4adf-842d-4cba2d3e75e2	c98edd27-0efb-4ae1-acd5-f4f94c297177	new_message	New message from Nnamdi Onwukwe	Hello	{"booking_id": null}	f	\N	in_app	normal	/bookings/null	\N	\N	2026-09-05 23:10:36.972835+00
68434f02-2de1-4a71-9cc9-1375fd20efde	c98edd27-0efb-4ae1-acd5-f4f94c297177	new_message	New message from Nnamdi Onwukwe	really	{"booking_id": null}	f	\N	in_app	normal	/bookings/null	\N	\N	2026-09-05 23:10:57.441226+00
0c6faa96-2ec8-4f4e-8e0c-4cc8b8172136	c98edd27-0efb-4ae1-acd5-f4f94c297177	ticket_created	Support ticket received 🎫	Your ticket "Test Ticket from API" has been submitted. We'll respond within 24 hours.	{}	f	\N	in_app	normal	/support/tickets/17ff1fa6-0ddb-4eca-8103-873b3e1498a6	\N	\N	2026-09-06 16:37:43.671794+00
bddd0d42-5945-47b6-981d-140d326084a9	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	ticket_created	Support ticket received 🎫	Your ticket "febverv" has been submitted. We'll respond within 24 hours.	{}	f	\N	in_app	normal	/support/tickets/270e99dc-60fa-4435-a265-896cf494cc5c	\N	\N	2026-09-06 16:38:21.137339+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, booking_id, user_id, amount, currency, payment_method, status, reference, created_at, updated_at, stripe_payment_id, stripe_session_id, gateway, platform_fee, maid_payout, payout_status, payout_at, bank_transfer_ref, bank_transfer_proof, bank_transfer_status, crypto_charge_id, crypto_charge_code, crypto_currency, crypto_amount, crypto_address, crypto_expires_at, notes, paid_at, customer_id, crypto_tx_hash, crypto_proof_url, crypto_amount_sent, crypto_status, paystack_reference, paystack_access_code) FROM stdin;
\.


--
-- Data for Name: pin_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pin_attempts (id, user_id, success, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_settings (key, value, description, updated_by, updated_at) FROM stdin;
platform_fee_customer	10	Customer service fee percent	\N	2026-09-05 22:12:03.571103+00
platform_fee_maid	0	Maid commission percent	\N	2026-09-05 22:12:03.571103+00
withdrawal_min_ngn	2000	Minimum withdrawal in NGN	\N	2026-09-05 22:12:03.571103+00
withdrawal_fee_tier1	200	Withdrawal fee under 10k NGN	\N	2026-09-05 22:12:03.571103+00
withdrawal_fee_tier2	350	Withdrawal fee 10k-50k NGN	\N	2026-09-05 22:12:03.571103+00
withdrawal_fee_tier3	500	Withdrawal fee 50k-200k NGN	\N	2026-09-05 22:12:03.571103+00
withdrawal_fee_tier4	750	Withdrawal fee above 200k NGN	\N	2026-09-05 22:12:03.571103+00
booking_auto_cancel_hrs	24	Hours before auto-cancelling unpaid bookings	\N	2026-09-05 22:12:03.571103+00
max_booking_duration	24	Maximum booking duration in hours	\N	2026-09-05 22:12:03.571103+00
platform_maintenance	false	Put platform in maintenance mode	\N	2026-09-05 22:12:03.571103+00
new_registrations	true	Allow new user registrations	\N	2026-09-05 22:12:03.571103+00
support_email	"support@deusizisparkle.com"	Support email address	\N	2026-09-05 22:12:03.571103+00
support_phone	"+2348000000000"	Support phone number	\N	2026-09-05 22:12:03.571103+00
supported_countries	["NG", "GH", "KE", "ZA", "GB", "US", "CA", "AU"]	Supported countries	\N	2026-09-05 22:12:03.571103+00
\.


--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promo_codes (id, code, description, discount_type, discount_value, currency, max_uses, uses_count, min_plan, valid_from, valid_until, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: push_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_tokens (id, user_id, token, platform, device_id, is_active, created_at, updated_at) FROM stdin;
f045cf6c-0fa5-4d12-9178-8a2d092a53d7	c98edd27-0efb-4ae1-acd5-f4f94c297177	ExponentPushToken[6O8cSaOc1KvAuHQKGrOqe3]	android	\N	t	2026-09-05 22:54:31.548786+00	2026-09-05 23:29:21.685044+00
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews (id, booking_id, reviewer_id, maid_id, rating, comment, created_at, customer_id) FROM stdin;
\.


--
-- Data for Name: sos_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sos_alerts (id, booking_id, triggered_by, lat, lng, address, message, status, resolved_by, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_invoices (id, subscription_id, user_id, amount, currency, status, gateway, gateway_ref, period_start, period_end, paid_at, failure_reason, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, display_name, description, target_role, plan_type, "interval", prices, features, bookings_per_month, discount_percent, priority_matching, dedicated_support, badge, trial_days, is_active, is_featured, sort_order, stripe_price_ids, paystack_plan_codes, created_at, updated_at) FROM stdin;
4a2e8ad5-2664-461a-a06a-7d47ae37bafd	free	Free	Get started with basic access	customer	recurring	monthly	{"AUD": 0, "CAD": 0, "EUR": 0, "GBP": 0, "GHS": 0, "KES": 0, "NGN": 0, "USD": 0, "ZAR": 0}	["Book maids on demand", "Standard matching", "Email support"]	2	0	f	f	\N	0	t	f	0	{}	{}	2026-09-05 22:12:04.113671+00	2026-09-05 22:12:04.113671+00
2b986061-1992-4847-95be-12c6ce64d385	basic	Basic	For occasional cleaning needs	customer	recurring	monthly	{"AUD": 8, "CAD": 7, "EUR": 4.5, "GBP": 4, "GHS": 70, "KES": 700, "NGN": 2500, "USD": 5, "ZAR": 95}	["1 booking/month included", "5% discount on all bookings", "Email support", "Cancel anytime"]	1	5	f	f	basic	0	t	f	1	{}	{}	2026-09-05 22:12:04.113671+00	2026-09-05 22:12:04.113671+00
a6219ad9-eb64-43f9-81af-6ae963b2eeaf	standard	Standard	Our most popular plan	customer	recurring	monthly	{"AUD": 18, "CAD": 16, "EUR": 11, "GBP": 10, "GHS": 165, "KES": 1600, "NGN": 6000, "USD": 12, "ZAR": 220}	["3 bookings/month included", "10% discount on all bookings", "Priority matching", "Chat support", "Booking reminders"]	3	10	t	f	standard	0	t	t	2	{}	{}	2026-09-05 22:12:04.113671+00	2026-09-05 22:12:04.113671+00
93843a8a-c5dc-4182-9f49-27edbcf062c5	premium	Premium	For homes that need regular cleaning	customer	recurring	monthly	{"AUD": 45, "CAD": 40, "EUR": 27, "GBP": 24, "GHS": 410, "KES": 4000, "NGN": 15000, "USD": 30, "ZAR": 550}	["Unlimited bookings", "15% discount on all bookings", "Priority matching", "Dedicated support", "Same-day booking", "Verified maids only", "Monthly report"]	\N	15	t	t	premium	0	t	f	3	{}	{}	2026-09-05 22:12:04.113671+00	2026-09-05 22:12:04.113671+00
c4c7550b-749e-4bef-8b1d-6851baa1d387	pro_badge	Verified Pro	Stand out and earn more	maid	annual	annual	{"AUD": 16, "CAD": 14, "EUR": 9, "GBP": 8, "GHS": 140, "KES": 1400, "NGN": 5000, "USD": 10, "ZAR": 185}	["Verified Pro badge on profile", "Priority listing in search", "Background check certificate", "Trust badge on bookings", "20% more booking visibility"]	\N	0	t	f	pro	0	t	f	0	{}	{}	2026-09-05 22:12:04.113671+00	2026-09-05 22:12:04.113671+00
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, user_id, plan_id, status, currency, amount, "interval", current_period_start, current_period_end, trial_start, trial_end, cancelled_at, cancel_at_period_end, cancellation_reason, paused_at, resumed_at, gateway, paystack_sub_code, paystack_email_token, stripe_sub_id, stripe_customer_id, promo_code, discount_percent, bookings_used, auto_renew, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: support_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_conversations (id, customer_id, unread_customer, unread_admin, deleted_by_customer, deleted_at_customer, created_at, updated_at) FROM stdin;
6ba89e00-006d-4b7c-9a3b-d46498869147	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	0	1	f	\N	2026-09-05 23:09:59.923528+00	2026-09-05 23:10:07.200971+00
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_messages (id, conversation_id, sender_id, content, message_type, media_url, media_type, is_read, deleted_at, deleted_by, created_at) FROM stdin;
7487d078-8773-4034-95c0-4e36059bced5	6ba89e00-006d-4b7c-9a3b-d46498869147	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	welcome	text	\N	\N	f	\N	\N	2026-09-05 23:10:07.198656+00
\.


--
-- Data for Name: support_ticket_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_ticket_attachments (id, ticket_id, ticket_type, user_id, media_url, media_type, file_name, file_size, created_at) FROM stdin;
\.


--
-- Data for Name: supported_currencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supported_currencies (code, name, symbol, is_active, paystack_supported, stripe_supported) FROM stdin;
NGN	Nigerian Naira	₦	t	t	f
USD	US Dollar	$	t	f	t
GBP	British Pound	£	t	f	t
EUR	Euro	€	t	f	t
KES	Kenyan Shilling	KSh	t	t	f
GHS	Ghanaian Cedi	₵	t	t	f
ZAR	South African Rand	R	t	f	t
CAD	Canadian Dollar	CA$	t	f	t
AUD	Australian Dollar	A$	t	f	t
\.


--
-- Data for Name: supported_languages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supported_languages (code, name, native_name, rtl, is_active) FROM stdin;
en	English	English	f	t
fr	French	Français	f	t
ar	Arabic	العربية	t	t
yo	Yoruba	Yorùbá	f	t
ha	Hausa	Hausa	f	t
ig	Igbo	Igbo	f	t
sw	Swahili	Kiswahili	f	t
pt	Portuguese	Português	f	t
es	Spanish	Español	f	t
de	German	Deutsch	f	t
zh	Chinese	中文	f	t
hi	Hindi	हिन्दी	f	t
id	Indonesian	Bahasa Indonesia	f	t
tr	Turkish	Türkçe	f	t
ru	Russian	Русский	f	t
\.


--
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_devices (id, user_id, device_hash, user_agent, ip_address, last_seen_at, created_at) FROM stdin;
725e89a2-0116-4af3-8622-7f578fe32217	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	c1ccbd77e337b2b7	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36	102.91.92.56	2026-09-05 22:32:37.139588+00	2026-09-05 22:32:37.139588+00
cb7c25fe-1d6e-4260-aa2f-620e4649462f	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	51173e18600fe73b	okhttp/4.9.2	102.91.92.56	2026-09-05 22:59:34.463594+00	2026-09-05 22:59:34.463594+00
9bda45bd-4103-45f7-adf9-25de653565f7	c98edd27-0efb-4ae1-acd5-f4f94c297177	51173e18600fe73b	okhttp/4.9.2	102.91.92.56	2026-09-05 23:29:18.526125+00	2026-09-05 22:54:29.496466+00
1c3d3ee5-ba66-48f0-9e5c-f882f0fe8f97	c98edd27-0efb-4ae1-acd5-f4f94c297177	07d1d539047ef019	curl/8.5.0	137.184.29.223	2026-09-06 16:36:55.90436+00	2026-09-05 23:31:16.669395+00
81ca7685-ba93-46dd-bc2f-8ca46d134e1f	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	07d1d539047ef019	curl/8.5.0	137.184.29.223	2026-09-06 16:48:30.058874+00	2026-09-05 22:44:11.523287+00
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_settings (id, user_id, language, currency, theme, notifications_email, notifications_push, notifications_sms, created_at, updated_at) FROM stdin;
e695377c-c12c-47cd-b941-94b0b92be390	c4d63344-111f-4d7a-8d07-993e34924dc2	en	NGN	system	t	t	f	2026-09-05 22:26:09.852915+00	2026-09-05 22:26:09.852915+00
374d34f8-9de7-48ba-abe5-2d7ed3e7f197	a8783d15-67b0-4efe-8a1e-08d4eaff1c12	en	NGN	system	t	t	f	2026-09-05 22:27:22.126037+00	2026-09-05 22:27:22.126037+00
2ba5165a-6e20-4930-8604-34982fca3d48	b7d2d3b4-1913-4924-804f-e50542a67bcb	en	NGN	system	t	t	f	2026-09-05 22:29:47.910711+00	2026-09-05 22:29:47.910711+00
c4e099d8-7d43-48f7-8957-206738c1c6ba	c98edd27-0efb-4ae1-acd5-f4f94c297177	en	NGN	system	t	t	f	2026-09-05 22:54:29.488214+00	2026-09-05 22:54:29.488214+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, full_name, phone, role, is_verified, is_active, created_at, updated_at, country, language, timezone, last_seen_at, admin_notes, flagged, flag_reason, banned_at, ban_reason, subscription_plan, subscription_badge, transaction_pin_hash, pin_set_at, pin_failed_attempts, pin_locked_until, google_id, google_email, google_name, google_picture, facebook_id, facebook_email, facebook_name, apple_id, apple_email, apple_name, reset_password_token, reset_password_expires, email_verified, email_verification_token, email_verification_expires, name, avatar, auth_provider, auth_provider_id, email_verify_token, email_verify_expires, reset_token, reset_token_expires) FROM stdin;
c4d63344-111f-4d7a-8d07-993e34924dc2	test@example.com	6053f2ba109d489f4b993f3afe6b3b47:316a04a977aaa96a7fa515863d9388cc26ce5b4b8fda069ce7ad4a43fdd12944a0817231f7e5ba2431682d525665f02238962c955c2f4d5edbcf03838c2aed97	\N	\N	customer	f	t	2026-09-05 22:26:09.848705+00	2026-09-05 22:26:09.848705+00	NG	en	Africa/Lagos	\N	\N	f	\N	\N	\N	free	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	Test User	\N	email	\N	f4ce34938df9531d996a4afdde3dec5fae09ea06d6bf46da59eea44031473f82	2026-09-06 22:26:09.847+00	\N	\N
b7d2d3b4-1913-4924-804f-e50542a67bcb	john@example.com	6fbfcb52a11218342070e88a0fc99f92:06dba004f763f35fed1cf8643d9575d2ce4ff95ed9fd7a6e5b0e33516d4cb1de77f9578a36dbb1e0a0d8d4bb8155432b09a8d75f51b6b10fb7b0dfe783b73cc6	\N	\N	customer	f	t	2026-09-05 22:29:47.908173+00	2026-09-05 22:29:47.908173+00	NG	en	Africa/Lagos	\N	\N	f	\N	\N	\N	free	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	John Doe	\N	email	\N	2857c76c572b23786341f6e7f8b68d0a56aad03e18f7eeb25f6dd94763753638	2026-09-06 22:29:47.907+00	\N	\N
a8783d15-67b0-4efe-8a1e-08d4eaff1c12	nnamdionwukwe@gmail.com	73e36f558be56c6a5871e12caa5a6fbf:7ebbfa4e454f9d86e6c1c1a89e5740bc2b53a98b2bedfb1112e16b7d19982f68b3099cc9c2db768628367d0d58ecb232d75943d0e36f6d18897aa93ee9975b14	\N	3456345643534	customer	f	t	2026-09-05 22:27:22.121579+00	2026-09-05 22:59:34.459747+00	NG	en	Africa/Lagos	\N	\N	f	\N	\N	\N	free	\N	\N	\N	0	\N	104044817013808202044	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	Nnamdi Onwukwe	https://lh3.googleusercontent.com/a/ACg8ocKpBTD2GMSNfY0crAr6dqyYCsh15Hf-Vmcjv9gvkD4J2uc6horO=s96-c	email	\N	\N	\N	\N	\N
c98edd27-0efb-4ae1-acd5-f4f94c297177	gestechc@gmail.com	6b732d108ced80aa4241fa621bc7f1f5:461a2b44668ef979d869c01fc8c4346318c79aa598a87e2b989d0ce9f55e5a61d14378614f915e388acb7ffeaeb6d44ab0224214eabb9ac88de4604d0261a70f	\N	\N	maid	f	t	2026-09-05 22:54:29.475125+00	2026-09-05 23:29:04.040355+00	NG	en	Africa/Lagos	\N	\N	f	\N	\N	\N	free	\N	\N	\N	0	\N	111615245218332982472	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	GESTech Company	https://lh3.googleusercontent.com/a/ACg8ocLwUwrY6NyUI4lDvDpCkgT4Lpg9z4nNtaBJEMq29HDB4AeY_-8=s96-c	email	\N	\N	\N	\N	\N
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallet_transactions (id, maid_id, type, amount, currency, source, source_id, balance_before, balance_after, description, created_at, booking_id, reference, withdrawal_id) FROM stdin;
6fd44a97-edb7-47a3-aa5e-69ed25d3b9ff	c98edd27-0efb-4ae1-acd5-f4f94c297177	credit	15000.00	NGN	booking	\N	0	25000.00	Payment for booking	2026-09-05 23:21:40.061927+00	\N	\N	\N
\.


--
-- Data for Name: withdrawals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.withdrawals (id, maid_id, amount, currency, method, status, bank_name, account_number, account_name, bank_code, bank_country, swift_code, iban, bank_address, mobile_provider, mobile_number, mobile_country, crypto_currency, crypto_address, crypto_network, paypal_email, wise_email, wise_account_id, flw_reference, fee, net_amount, gateway_ref, gateway_response, notes, failure_reason, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- Name: admin_reports admin_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_reports
    ADD CONSTRAINT admin_reports_pkey PRIMARY KEY (id);


--
-- Name: booking_locations booking_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_locations
    ADD CONSTRAINT booking_locations_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: conversations chat_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT chat_conversations_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: customer_support_replies customer_support_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_support_replies
    ADD CONSTRAINT customer_support_replies_pkey PRIMARY KEY (id);


--
-- Name: customer_support_tickets customer_support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_support_tickets
    ADD CONSTRAINT customer_support_tickets_pkey PRIMARY KEY (id);


--
-- Name: emergency_contacts emergency_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_pkey PRIMARY KEY (id);


--
-- Name: maid_availability maid_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_availability
    ADD CONSTRAINT maid_availability_pkey PRIMARY KEY (id);


--
-- Name: maid_bank_details maid_bank_details_maid_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_bank_details
    ADD CONSTRAINT maid_bank_details_maid_id_key UNIQUE (maid_id);


--
-- Name: maid_bank_details maid_bank_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_bank_details
    ADD CONSTRAINT maid_bank_details_pkey PRIMARY KEY (id);


--
-- Name: maid_documents maid_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_documents
    ADD CONSTRAINT maid_documents_pkey PRIMARY KEY (id);


--
-- Name: maid_payouts maid_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_payouts
    ADD CONSTRAINT maid_payouts_pkey PRIMARY KEY (id);


--
-- Name: maid_profiles maid_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_profiles
    ADD CONSTRAINT maid_profiles_pkey PRIMARY KEY (id);


--
-- Name: maid_support_conversations maid_support_conversations_maid_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_conversations
    ADD CONSTRAINT maid_support_conversations_maid_id_key UNIQUE (maid_id);


--
-- Name: maid_support_conversations maid_support_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_conversations
    ADD CONSTRAINT maid_support_conversations_pkey PRIMARY KEY (id);


--
-- Name: maid_support_messages maid_support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_messages
    ADD CONSTRAINT maid_support_messages_pkey PRIMARY KEY (id);


--
-- Name: maid_support_replies maid_support_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_replies
    ADD CONSTRAINT maid_support_replies_pkey PRIMARY KEY (id);


--
-- Name: maid_support_tickets maid_support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_tickets
    ADD CONSTRAINT maid_support_tickets_pkey PRIMARY KEY (id);


--
-- Name: maid_wallets maid_wallets_maid_id_currency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_wallets
    ADD CONSTRAINT maid_wallets_maid_id_currency_key UNIQUE (maid_id, currency);


--
-- Name: maid_wallets maid_wallets_maid_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_wallets
    ADD CONSTRAINT maid_wallets_maid_id_key UNIQUE (maid_id);


--
-- Name: maid_wallets maid_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_wallets
    ADD CONSTRAINT maid_wallets_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: ng_banks ng_banks_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ng_banks
    ADD CONSTRAINT ng_banks_code_key UNIQUE (code);


--
-- Name: ng_banks ng_banks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ng_banks
    ADD CONSTRAINT ng_banks_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pin_attempts pin_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_attempts
    ADD CONSTRAINT pin_attempts_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (key);


--
-- Name: promo_codes promo_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_code_key UNIQUE (code);


--
-- Name: promo_codes promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: push_tokens push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_pkey PRIMARY KEY (id);


--
-- Name: push_tokens push_tokens_user_id_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_user_id_token_key UNIQUE (user_id, token);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: sos_alerts sos_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sos_alerts
    ADD CONSTRAINT sos_alerts_pkey PRIMARY KEY (id);


--
-- Name: subscription_invoices subscription_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_user_id_status_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_status_key UNIQUE (user_id, status) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: support_conversations support_conversations_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_conversations
    ADD CONSTRAINT support_conversations_customer_id_key UNIQUE (customer_id);


--
-- Name: support_conversations support_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_conversations
    ADD CONSTRAINT support_conversations_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_ticket_attachments support_ticket_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_ticket_attachments
    ADD CONSTRAINT support_ticket_attachments_pkey PRIMARY KEY (id);


--
-- Name: supported_currencies supported_currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supported_currencies
    ADD CONSTRAINT supported_currencies_pkey PRIMARY KEY (code);


--
-- Name: supported_languages supported_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supported_languages
    ADD CONSTRAINT supported_languages_pkey PRIMARY KEY (code);


--
-- Name: user_devices user_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_pkey PRIMARY KEY (id);


--
-- Name: user_devices user_devices_user_id_device_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_user_id_device_hash_key UNIQUE (user_id, device_hash);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: withdrawals withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_admin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_admin ON public.admin_audit_log USING btree (admin_id, created_at DESC);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_created ON public.admin_audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.admin_audit_log USING btree (entity_type, entity_id);


--
-- Name: idx_booking_locations_booking; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_booking_locations_booking ON public.booking_locations USING btree (booking_id, recorded_at DESC);


--
-- Name: idx_booking_locations_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_booking_locations_booking_id ON public.booking_locations USING btree (booking_id);


--
-- Name: idx_booking_locations_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_booking_locations_recorded_at ON public.booking_locations USING btree (recorded_at DESC);


--
-- Name: idx_bookings_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_customer ON public.bookings USING btree (customer_id, status);


--
-- Name: idx_bookings_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_customer_id ON public.bookings USING btree (customer_id);


--
-- Name: idx_bookings_escrow_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_escrow_status ON public.bookings USING btree (escrow_status);


--
-- Name: idx_bookings_maid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_maid ON public.bookings USING btree (maid_id, status);


--
-- Name: idx_bookings_maid_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_maid_id ON public.bookings USING btree (maid_id);


--
-- Name: idx_bookings_service_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_service_date ON public.bookings USING btree (service_date);


--
-- Name: idx_bookings_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_status ON public.bookings USING btree (status);


--
-- Name: idx_chat_conversations_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_conversations_booking_id ON public.conversations USING btree (booking_id);


--
-- Name: idx_chat_conversations_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_conversations_customer_id ON public.conversations USING btree (customer_id);


--
-- Name: idx_chat_conversations_maid_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_conversations_maid_id ON public.conversations USING btree (maid_id);


--
-- Name: idx_chat_messages_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_conversation_id ON public.chat_messages USING btree (conversation_id);


--
-- Name: idx_chat_messages_is_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_is_read ON public.chat_messages USING btree (is_read);


--
-- Name: idx_chat_messages_receiver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_receiver_id ON public.chat_messages USING btree (receiver_id);


--
-- Name: idx_chat_messages_sender_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_sender_id ON public.chat_messages USING btree (sender_id);


--
-- Name: idx_conversations_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_booking_id ON public.conversations USING btree (booking_id);


--
-- Name: idx_conversations_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_customer_id ON public.conversations USING btree (customer_id);


--
-- Name: idx_conversations_maid_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_maid_id ON public.conversations USING btree (maid_id);


--
-- Name: idx_conversations_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_type ON public.conversations USING btree (type);


--
-- Name: idx_customer_support_replies_ticket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_support_replies_ticket_id ON public.customer_support_replies USING btree (ticket_id);


--
-- Name: idx_customer_support_tickets_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_support_tickets_status ON public.customer_support_tickets USING btree (status);


--
-- Name: idx_customer_support_tickets_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_support_tickets_user_id ON public.customer_support_tickets USING btree (user_id);


--
-- Name: idx_emergency_contacts_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_emergency_contacts_user ON public.emergency_contacts USING btree (user_id);


--
-- Name: idx_maid_payouts_booking; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_payouts_booking ON public.maid_payouts USING btree (booking_id);


--
-- Name: idx_maid_payouts_maid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_payouts_maid ON public.maid_payouts USING btree (maid_id, status);


--
-- Name: idx_maid_profiles_is_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_profiles_is_available ON public.maid_profiles USING btree (is_available);


--
-- Name: idx_maid_profiles_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_profiles_location ON public.maid_profiles USING btree (latitude, longitude);


--
-- Name: idx_maid_profiles_rating; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_profiles_rating ON public.maid_profiles USING btree (rating);


--
-- Name: idx_maid_profiles_years_exp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_profiles_years_exp ON public.maid_profiles USING btree (years_exp);


--
-- Name: idx_maid_support_conv_maid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_conv_maid ON public.maid_support_conversations USING btree (maid_id);


--
-- Name: idx_maid_support_conv_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_conv_updated ON public.maid_support_conversations USING btree (updated_at DESC);


--
-- Name: idx_maid_support_msg_conv_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_msg_conv_id ON public.maid_support_messages USING btree (conversation_id);


--
-- Name: idx_maid_support_msg_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_msg_created ON public.maid_support_messages USING btree (created_at);


--
-- Name: idx_maid_support_msg_sender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_msg_sender ON public.maid_support_messages USING btree (sender_id);


--
-- Name: idx_maid_support_msg_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_msg_unread ON public.maid_support_messages USING btree (conversation_id, is_read) WHERE (is_read = false);


--
-- Name: idx_maid_support_replies_ticket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_replies_ticket_id ON public.maid_support_replies USING btree (ticket_id);


--
-- Name: idx_maid_support_replies_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_replies_user_id ON public.maid_support_replies USING btree (user_id);


--
-- Name: idx_maid_support_tickets_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_tickets_category ON public.maid_support_tickets USING btree (category);


--
-- Name: idx_maid_support_tickets_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_tickets_created_at ON public.maid_support_tickets USING btree (created_at);


--
-- Name: idx_maid_support_tickets_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_tickets_status ON public.maid_support_tickets USING btree (status);


--
-- Name: idx_maid_support_tickets_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maid_support_tickets_user_id ON public.maid_support_tickets USING btree (user_id);


--
-- Name: idx_messages_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_conversation_id ON public.messages USING btree (conversation_id);


--
-- Name: idx_messages_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_deleted_at ON public.messages USING btree (deleted_at);


--
-- Name: idx_notif_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notif_created ON public.notifications USING btree (created_at DESC);


--
-- Name: idx_notif_user_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notif_user_type ON public.notifications USING btree (user_id, type, created_at DESC);


--
-- Name: idx_notif_user_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notif_user_unread ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_payments_paystack_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_paystack_reference ON public.payments USING btree (paystack_reference);


--
-- Name: idx_pin_attempts_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pin_attempts_user ON public.pin_attempts USING btree (user_id, created_at DESC);


--
-- Name: idx_push_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_push_tokens_user ON public.push_tokens USING btree (user_id, is_active);


--
-- Name: idx_reviews_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reviews_customer_id ON public.reviews USING btree (customer_id);


--
-- Name: idx_reviews_maid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reviews_maid ON public.reviews USING btree (maid_id);


--
-- Name: idx_sos_alerts_booking; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sos_alerts_booking ON public.sos_alerts USING btree (booking_id);


--
-- Name: idx_sos_alerts_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sos_alerts_booking_id ON public.sos_alerts USING btree (booking_id);


--
-- Name: idx_sos_alerts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sos_alerts_status ON public.sos_alerts USING btree (status, created_at DESC);


--
-- Name: idx_sub_invoices_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_invoices_sub ON public.subscription_invoices USING btree (subscription_id);


--
-- Name: idx_sub_invoices_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_invoices_user ON public.subscription_invoices USING btree (user_id, created_at DESC);


--
-- Name: idx_subs_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_expiry ON public.subscriptions USING btree (current_period_end, status);


--
-- Name: idx_subs_gateway_paystack; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_gateway_paystack ON public.subscriptions USING btree (paystack_sub_code) WHERE (paystack_sub_code IS NOT NULL);


--
-- Name: idx_subs_gateway_stripe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_gateway_stripe ON public.subscriptions USING btree (stripe_sub_id) WHERE (stripe_sub_id IS NOT NULL);


--
-- Name: idx_subs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subs_user ON public.subscriptions USING btree (user_id, status);


--
-- Name: idx_support_conv_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_customer ON public.support_conversations USING btree (customer_id);


--
-- Name: idx_support_conv_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_updated ON public.support_conversations USING btree (updated_at DESC);


--
-- Name: idx_support_msg_conv_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_msg_conv_id ON public.support_messages USING btree (conversation_id);


--
-- Name: idx_support_msg_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_msg_created ON public.support_messages USING btree (created_at);


--
-- Name: idx_support_msg_sender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_msg_sender ON public.support_messages USING btree (sender_id);


--
-- Name: idx_support_msg_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_msg_unread ON public.support_messages USING btree (conversation_id, is_read) WHERE (is_read = false);


--
-- Name: idx_support_ticket_attachments_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_ticket_attachments_created_at ON public.support_ticket_attachments USING btree (created_at);


--
-- Name: idx_support_ticket_attachments_ticket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_ticket_attachments_ticket_id ON public.support_ticket_attachments USING btree (ticket_id);


--
-- Name: idx_support_ticket_attachments_ticket_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_ticket_attachments_ticket_type ON public.support_ticket_attachments USING btree (ticket_type);


--
-- Name: idx_support_ticket_attachments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_ticket_attachments_user_id ON public.support_ticket_attachments USING btree (user_id);


--
-- Name: idx_user_devices_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_devices_last_seen ON public.user_devices USING btree (last_seen_at);


--
-- Name: idx_user_devices_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_devices_user_id ON public.user_devices USING btree (user_id);


--
-- Name: idx_users_apple_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_apple_id ON public.users USING btree (apple_id);


--
-- Name: idx_users_auth_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_auth_provider ON public.users USING btree (auth_provider);


--
-- Name: idx_users_email_verify_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email_verify_token ON public.users USING btree (email_verify_token);


--
-- Name: idx_users_facebook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_facebook_id ON public.users USING btree (facebook_id);


--
-- Name: idx_users_google_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_google_id ON public.users USING btree (google_id);


--
-- Name: idx_users_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: idx_users_reset_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_reset_token ON public.users USING btree (reset_token);


--
-- Name: idx_wallet_tx_maid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_maid ON public.wallet_transactions USING btree (maid_id, created_at DESC);


--
-- Name: idx_withdrawals_maid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_withdrawals_maid ON public.withdrawals USING btree (maid_id, status);


--
-- Name: idx_withdrawals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_withdrawals_status ON public.withdrawals USING btree (status, created_at DESC);


--
-- Name: admin_audit_log admin_audit_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id);


--
-- Name: admin_reports admin_reports_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_reports
    ADD CONSTRAINT admin_reports_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(id);


--
-- Name: booking_locations booking_locations_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_locations
    ADD CONSTRAINT booking_locations_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: booking_locations booking_locations_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_locations
    ADD CONSTRAINT booking_locations_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id);


--
-- Name: bookings bookings_cancelled_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_cancelled_by_user_id_fkey FOREIGN KEY (cancelled_by_user_id) REFERENCES public.users(id);


--
-- Name: bookings bookings_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_escrow_released_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_escrow_released_by_fkey FOREIGN KEY (escrow_released_by) REFERENCES public.users(id);


--
-- Name: bookings bookings_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.maid_profiles(id) ON DELETE SET NULL;


--
-- Name: conversations chat_conversations_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT chat_conversations_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customer_support_replies customer_support_replies_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_support_replies
    ADD CONSTRAINT customer_support_replies_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.customer_support_tickets(id) ON DELETE CASCADE;


--
-- Name: customer_support_replies customer_support_replies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_support_replies
    ADD CONSTRAINT customer_support_replies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customer_support_tickets customer_support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_support_tickets
    ADD CONSTRAINT customer_support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: emergency_contacts emergency_contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_availability maid_availability_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_availability
    ADD CONSTRAINT maid_availability_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_bank_details maid_bank_details_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_bank_details
    ADD CONSTRAINT maid_bank_details_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_documents maid_documents_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_documents
    ADD CONSTRAINT maid_documents_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_payouts maid_payouts_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_payouts
    ADD CONSTRAINT maid_payouts_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id);


--
-- Name: maid_payouts maid_payouts_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_payouts
    ADD CONSTRAINT maid_payouts_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id);


--
-- Name: maid_payouts maid_payouts_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_payouts
    ADD CONSTRAINT maid_payouts_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: maid_payouts maid_payouts_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_payouts
    ADD CONSTRAINT maid_payouts_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: maid_profiles maid_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_profiles
    ADD CONSTRAINT maid_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_support_conversations maid_support_conversations_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_conversations
    ADD CONSTRAINT maid_support_conversations_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_support_messages maid_support_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_messages
    ADD CONSTRAINT maid_support_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.maid_support_conversations(id) ON DELETE CASCADE;


--
-- Name: maid_support_messages maid_support_messages_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_messages
    ADD CONSTRAINT maid_support_messages_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: maid_support_messages maid_support_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_messages
    ADD CONSTRAINT maid_support_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_support_replies maid_support_replies_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_replies
    ADD CONSTRAINT maid_support_replies_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.maid_support_tickets(id) ON DELETE CASCADE;


--
-- Name: maid_support_replies maid_support_replies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_replies
    ADD CONSTRAINT maid_support_replies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_support_tickets maid_support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_support_tickets
    ADD CONSTRAINT maid_support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maid_wallets maid_wallets_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maid_wallets
    ADD CONSTRAINT maid_wallets_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: messages messages_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: messages messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE SET NULL;


--
-- Name: payments payments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pin_attempts pin_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_attempts
    ADD CONSTRAINT pin_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: platform_settings platform_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: promo_codes promo_codes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: push_tokens push_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: reviews reviews_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sos_alerts sos_alerts_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sos_alerts
    ADD CONSTRAINT sos_alerts_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: sos_alerts sos_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sos_alerts
    ADD CONSTRAINT sos_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: sos_alerts sos_alerts_triggered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sos_alerts
    ADD CONSTRAINT sos_alerts_triggered_by_fkey FOREIGN KEY (triggered_by) REFERENCES public.users(id);


--
-- Name: subscription_invoices subscription_invoices_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: subscription_invoices subscription_invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: subscriptions subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_conversations support_conversations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_conversations
    ADD CONSTRAINT support_conversations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_messages support_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.support_conversations(id) ON DELETE CASCADE;


--
-- Name: support_messages support_messages_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: support_messages support_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_ticket_attachments support_ticket_attachments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_ticket_attachments
    ADD CONSTRAINT support_ticket_attachments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_devices user_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_settings user_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wallet_transactions wallet_transactions_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id);


--
-- Name: wallet_transactions wallet_transactions_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id);


--
-- Name: wallet_transactions wallet_transactions_withdrawal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_withdrawal_id_fkey FOREIGN KEY (withdrawal_id) REFERENCES public.withdrawals(id);


--
-- Name: withdrawals withdrawals_maid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_maid_id_fkey FOREIGN KEY (maid_id) REFERENCES public.users(id);


--
-- Name: withdrawals withdrawals_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict gmG8DUuKwSzJv75wd55sUb5lH2dndhJp4YTzkK1YK8FKDFwE6s3ibgtbcnV939P

