// src/controllers/auth.js
import jwt from "jsonwebtoken";
import { safeGet, safeSet, safeDel } from "../config/redis.js";
import crypto from "crypto";
import {
  sendVerificationEmail,
  sendNewLoginAlert,
  sendPasswordResetEmail,
  sendWelcomeEmail,
} from "../utils/mailer.js";

// ── Helpers ────────────────────────────────────────────────────────────

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, (err, hash) => {
      if (err) reject(err);
      else resolve(`${salt}:${hash.toString("hex")}`);
    });
  });
}

async function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(":");
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, (err, derived) => {
      if (err) reject(err);
      else resolve(derived.toString("hex") === hash);
    });
  });
}

function getDeviceHash(req) {
  const ua = req.headers["user-agent"] || "";
  const lang = req.headers["accept-language"] || "";
  return crypto
    .createHash("sha256")
    .update(`${ua}${lang}`)
    .digest("hex")
    .slice(0, 16);
}

function getDeviceLabel(req) {
  const ua = req.headers["user-agent"] || "Unknown";
  if (ua.includes("Chrome")) return "Chrome Browser";
  if (ua.includes("Firefox")) return "Firefox Browser";
  if (ua.includes("Safari")) return "Safari Browser";
  if (ua.includes("Mobile")) return "Mobile Browser";
  return "Unknown Browser";
}

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES = process.env.JWT_EXPIRES || "30d";

function signToken(user) {
  if (!JWT_SECRET) throw new Error("JWT_SECRET not configured");
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    {
      expiresIn: JWT_EXPIRES,
    },
  );
}

// Record device + send new-device alert if first time from this device
async function handleDeviceTracking(db, user, req) {
  const deviceHash = getDeviceHash(req);
  const ip =
    req.headers["x-forwarded-for"]?.split(",")[0] ||
    req.socket?.remoteAddress ||
    "unknown";
  const userAgent = req.headers["user-agent"] || "unknown";

  const { rows: deviceRows } = await db.query(
    `SELECT id FROM user_devices WHERE user_id = $1 AND device_hash = $2`,
    [user.id, deviceHash],
  );

  if (deviceRows.length === 0) {
    await db.query(
      `INSERT INTO user_devices (user_id, device_hash, user_agent, ip_address)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (user_id, device_hash) DO UPDATE SET last_seen_at = now(), ip_address = $4`,
      [user.id, deviceHash, userAgent, ip],
    );
    // Fire and forget — don't block login
    sendNewLoginAlert(user, {
      ip,
      userAgent,
      device: getDeviceLabel(req),
    }).catch(console.error);
  } else {
    await db.query(
      `UPDATE user_devices SET last_seen_at = now(), ip_address = $1
       WHERE user_id = $2 AND device_hash = $3`,
      [ip, user.id, deviceHash],
    );
  }
}

// ── Google Login / Register ────────────────────────────────────────────
export const googleLogin = async (req, res) => {
  const { access_token, role = "customer" } = req.body;

  if (!access_token)
    return res.status(400).json({ error: "access_token is required" });
  if (!["customer", "maid"].includes(role))
    return res.status(400).json({ error: "role must be customer or maid" });

  // 1. Verify Google token
  let googleUser;
  try {
    const response = await fetch(
      "https://www.googleapis.com/oauth2/v3/userinfo",
      {
        headers: { Authorization: `Bearer ${access_token}` },
      },
    );
    if (!response.ok)
      return res.status(401).json({ error: "invalid google access token" });
    googleUser = await response.json();
  } catch {
    return res.status(401).json({ error: "failed to verify google token" });
  }

  const { sub: google_id, email, name, picture: google_avatar } = googleUser;
  if (!google_id || !email)
    return res.status(401).json({ error: "incomplete google profile" });

  try {
    // 2. Find user by google_id OR email
    const { rows: existing } = await req.db.query(
      `SELECT * FROM users WHERE google_id = $1 OR email = $2 LIMIT 1`,
      [google_id, email],
    );

    let user;
    let isNewUser = false;

    if (existing.length > 0) {
      const found = existing[0];

      // ✅ EXISTING USER: Only update google_id if missing, NEVER overwrite name
      const { rows: updated } = await req.db.query(
        `UPDATE users
         SET google_id  = COALESCE(google_id, $1),
             is_active  = true,
             updated_at = now()
         WHERE id = $2
         RETURNING *`,
        [google_id, found.id],
      );
      user = updated[0];

      // ✅ If user has no avatar, set Google avatar (but don't overwrite custom avatar)
      if (!user.avatar && google_avatar) {
        await req.db.query(`UPDATE users SET avatar = $1 WHERE id = $2`, [
          google_avatar,
          user.id,
        ]);
        user.avatar = google_avatar;
      }
    } else {
      // ── NEW USER: Create with Google name and avatar
      isNewUser = true;

      const { rows: inserted } = await req.db.query(
        `INSERT INTO users (email, name, avatar, google_id, role, is_active, email_verified)
         VALUES ($1, $2, $3, $4, $5, true, true)
         RETURNING *`,
        [email, name, google_avatar, google_id, role],
      );
      user = inserted[0];

      if (role === "maid") {
        await req.db.query(
          `INSERT INTO maid_profiles (user_id, hourly_rate, is_available)
           SELECT $1, 0, false
           WHERE NOT EXISTS (SELECT 1 FROM maid_profiles WHERE user_id = $1)`,
          [user.id],
        );
      }

      await req.db.query(
        `INSERT INTO user_settings (user_id, language, currency)
         SELECT $1, 'en', 'NGN'
         WHERE NOT EXISTS (SELECT 1 FROM user_settings WHERE user_id = $1)`,
        [user.id],
      );
    }

    // 3. Device tracking
    await handleDeviceTracking(req.db, user, req);

    // 4. Sign token
    const token = signToken(user);

    // ✅ 5. Get user with maid profile data
    const { rows: userWithProfile } = await req.db.query(
      `SELECT u.id, u.name, u.email, u.avatar, u.role, u.phone, u.country,
          u.language, u.email_verified, u.auth_provider, u.created_at,
          u.subscription_plan, u.subscription_badge,
          s.theme, s.currency, s.notifications_email, s.notifications_push,
          COALESCE(mp.id_verified, false) AS id_verified,
          COALESCE(mp.background_checked, false) AS background_checked,
          CASE 
            WHEN u.subscription_plan IS NOT NULL 
             AND u.subscription_plan != 'free'
             AND u.subscription_badge IS NOT NULL
            THEN true 
            ELSE false 
          END AS has_pro_badge
   FROM users u
   LEFT JOIN user_settings s ON s.user_id = u.id
   LEFT JOIN maid_profiles mp ON mp.user_id = u.id
   WHERE u.id = $1 AND u.is_active = true`,
      [user.id],
    );

    const fullUser = userWithProfile[0] || user;

    // 6. Cache user
    const { password_hash, ...safeUser } = fullUser;
    await safeSet(`user:${user.id}`, 60 * 5, JSON.stringify(safeUser));

    return res.status(200).json({
      token,
      user: safeUser,
      isNewUser,
      needsPhone: !!user.google_id && !user.phone,
    });
  } catch (err) {
    console.error("[googleLogin]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Complete profile (phone number after Google register) ─────────────
export const completeProfile = async (req, res) => {
  const { phone } = req.body;

  if (!phone) return res.status(400).json({ error: "phone is required" });
  if (!/^\+?[\d\s\-()]{7,15}$/.test(phone)) {
    return res
      .status(400)
      .json({ error: "enter a valid phone number with country code" });
  }

  try {
    const { rows } = await req.db.query(
      `UPDATE users SET phone = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [phone, req.user.id],
    );
    if (!rows.length) return res.status(404).json({ error: "user not found" });

    const user = rows[0];

    // Send welcome email now that profile is complete
    sendWelcomeEmail(user).catch(console.error);

    // Bust cache so next /me returns fresh data
    await safeDel(`user:${user.id}`);

    const { password_hash, ...safeUser } = user;
    return res.json({ message: "Profile updated", user: safeUser });
  } catch (err) {
    console.error("[completeProfile]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Get current user ───────────────────────────────────────────────────
export const getMe = async (req, res) => {
  try {
    // Always skip cache so badge/subscription changes show immediately
    await safeDel(`user:${req.user.id}`);

    const { rows } = await req.db.query(
      `SELECT u.id, u.name, u.email, u.avatar, u.role, u.phone, u.country,
          u.language, u.email_verified, u.auth_provider, u.created_at,
          u.subscription_plan, u.subscription_badge,
          s.theme, s.currency, s.notifications_email, s.notifications_push,
          COALESCE(mp.id_verified, false) AS id_verified,
          COALESCE(mp.background_checked, false) AS background_checked,
          -- Pro badge = has active paid subscription with a badge
          CASE 
            WHEN u.subscription_plan IS NOT NULL 
             AND u.subscription_plan != 'free'
             AND u.subscription_badge IS NOT NULL
            THEN true 
            ELSE false 
          END AS has_pro_badge
   FROM users u
   LEFT JOIN user_settings s ON s.user_id = u.id
   LEFT JOIN maid_profiles mp ON mp.user_id = u.id
   WHERE u.id = $1 AND u.is_active = true`,
      [req.user.id],
    );

    if (!rows.length) return res.status(404).json({ error: "user not found" });

    await safeSet(`user:${rows[0].id}`, 60 * 5, JSON.stringify(rows[0]));
    return res.json({ user: rows[0] });
  } catch (err) {
    console.error("[getMe]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Logout ────────────────────────────────────────────────────────────
export const logout = async (req, res) => {
  try {
    await safeDel(`user:${req.user.id}`);
    return res.json({ message: "logged out" });
  } catch (err) {
    console.error("[logout]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Register with email/password ──────────────────────────────────────
export const register = async (req, res) => {
  const {
    name,
    email,
    password,
    role = "customer",
    phone,
    country = "NG",
    language = "en",
  } = req.body;

  if (!name || !email || !password)
    return res
      .status(400)
      .json({ error: "name, email and password are required" });
  if (!["customer", "maid"].includes(role))
    return res.status(400).json({ error: "role must be customer or maid" });
  if (password.length < 8)
    return res
      .status(400)
      .json({ error: "password must be at least 8 characters" });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error: "invalid email address" });

  try {
    // Check if email already exists
    const { rows: existing } = await req.db.query(
      `SELECT id, auth_provider, google_id FROM users WHERE email = $1`,
      [email.toLowerCase()],
    );

    if (existing.length) {
      const found = existing[0];
      if (found.google_id) {
        // Email exists via Google — add password to the account so they can use both
        const password_hash = await hashPassword(password);
        await req.db.query(
          `UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2`,
          [password_hash, found.id],
        );
        return res.status(409).json({
          error:
            "this email is already registered via Google sign-in. We've linked your password — please log in.",
          code: "GOOGLE_ACCOUNT_LINKED",
        });
      }
      return res.status(409).json({ error: "email already registered" });
    }

    const password_hash = await hashPassword(password);
    const verify_token = crypto.randomBytes(32).toString("hex");
    const verify_expires = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const { rows } = await req.db.query(
      `INSERT INTO users
         (email, name, role, phone, country, language, password_hash,
          auth_provider, email_verified, email_verify_token, email_verify_expires, is_active)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'email',false,$8,$9,true)
       RETURNING id, email, name, role, avatar, phone, country, language, email_verified, created_at`,
      [
        email.toLowerCase(),
        name,
        role,
        phone || null,
        country,
        language,
        password_hash,
        verify_token,
        verify_expires,
      ],
    );

    const user = rows[0];

    if (role === "maid") {
      await req.db.query(
        `INSERT INTO maid_profiles (user_id, hourly_rate, is_available)
 SELECT $1, 0, false WHERE NOT EXISTS (SELECT 1 FROM maid_profiles WHERE user_id = $1)`,
        [user.id],
      );
    }

    await req.db.query(
      `INSERT INTO user_settings (user_id, language, currency)
 SELECT $1, $2, 'NGN' WHERE NOT EXISTS (SELECT 1 FROM user_settings WHERE user_id = $1)`,
      [user.id, language],
    );

    sendVerificationEmail(user, verify_token).catch(console.error);

    return res.status(201).json({
      message:
        "Account created. Please check your email to verify your account.",
      user: { ...user, email_verified: false },
    });
  } catch (err) {
    console.error("[register]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Verify email ──────────────────────────────────────────────────────
export const verifyEmail = async (req, res) => {
  const { token } = req.params;
  if (!token) return res.status(400).json({ error: "token is required" });

  try {
    const { rows } = await req.db.query(
      `UPDATE users
       SET email_verified        = true,
           email_verify_token    = null,
           email_verify_expires  = null,
           updated_at            = now()
       WHERE email_verify_token  = $1
         AND email_verify_expires > now()
         AND email_verified       = false
       RETURNING id, email, name, role`,
      [token],
    );

    if (!rows.length) {
      return res
        .status(400)
        .json({ error: "invalid or expired verification link" });
    }

    const verifiedUser = rows[0];

    // Send welcome email — fire and forget
    sendWelcomeEmail(verifiedUser).catch(console.error);

    return res.json({
      message: "Email verified successfully. You can now log in.",
      user: verifiedUser,
    });
  } catch (err) {
    console.error("[verifyEmail]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Resend verification email ─────────────────────────────────────────
export const resendVerification = async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "email is required" });

  try {
    // 1. Look up the user first so we can log what's actually happening
    const { rows: userRows } = await req.db.query(
      `SELECT id, email, name, email_verified, is_active
       FROM users WHERE email = $1`,
      [email.toLowerCase()],
    );

    if (!userRows.length) {
      console.log(
        `[resendVerification] no user found for ${email.toLowerCase()}`,
      );
      return res.json({
        message:
          "If that email exists and is unverified, a new link has been sent.",
      });
    }

    const user = userRows[0];

    if (!user.is_active) {
      console.log(`[resendVerification] user ${user.email} is deactivated`);
      return res.json({
        message:
          "If that email exists and is unverified, a new link has been sent.",
      });
    }

    if (user.email_verified) {
      console.log(
        `[resendVerification] ${user.email} is already verified — no email sent`,
      );
      return res.json({
        message: "This email is already verified. You can sign in.",
        code: "ALREADY_VERIFIED",
      });
    }

    // 2. Generate fresh token
    const new_token = crypto.randomBytes(32).toString("hex");
    const new_expires = new Date(Date.now() + 24 * 60 * 60 * 1000);

    // 3. Update token in DB
    await req.db.query(
      `UPDATE users
       SET email_verify_token = $1,
           email_verify_expires = $2,
           updated_at = now()
       WHERE id = $3`,
      [new_token, new_expires, user.id],
    );

    // 4. Send the email — await it so logs reflect actual send result
    const result = await sendVerificationEmail(user, new_token);
    console.log(`[resendVerification] sent to ${user.email}, result:`, result);

    return res.json({
      message: "Verification link has been sent to your email.",
    });
  } catch (err) {
    console.error("[resendVerification]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Login with email/password ─────────────────────────────────────────
export const login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: "email and password are required" });

  try {
    const { rows } = await req.db.query(
      `SELECT id, email, name, avatar, role, password_hash, google_id,
              email_verified, is_active, country, language, phone
       FROM users WHERE email = $1`,
      [email.toLowerCase()],
    );

    if (!rows.length)
      return res.status(401).json({ error: "invalid email or password" });

    const user = rows[0];

    if (!user.is_active)
      return res.status(403).json({ error: "account has been deactivated" });

    // No password set — Google-only account that hasn't been linked yet
    if (!user.password_hash) {
      return res.status(400).json({
        error:
          'this account was created with Google sign-in and has no password. Please sign in with Google or use "Forgot password" to set a password.',
        code: "NO_PASSWORD_SET",
        has_google: !!user.google_id,
      });
    }

    const valid = await verifyPassword(password, user.password_hash);
    if (!valid)
      return res.status(401).json({ error: "invalid email or password" });

    if (!user.email_verified) {
      return res.status(403).json({
        error: "email not verified",
        code: "EMAIL_NOT_VERIFIED",
        message:
          "Please check your email and click the verification link before logging in.",
        email: user.email,
      });
    }

    // Device tracking
    await handleDeviceTracking(req.db, user, req);

    const token = signToken(user);
    const { password_hash, ...safeUser } = user;
    await safeSet(`user:${user.id}`, 60 * 5, JSON.stringify(safeUser));

    return res.json({ token, user: safeUser });
  } catch (err) {
    console.error("[login]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Forgot password ───────────────────────────────────────────────────
export const forgotPassword = async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "email is required" });

  try {
    const reset_token = crypto.randomBytes(32).toString("hex");
    const reset_expires = new Date(Date.now() + 60 * 60 * 1000);

    // Allow ANY user (including Google-created) to reset/set a password
    const { rows } = await req.db.query(
      `UPDATE users
       SET reset_token = $1, reset_token_expires = $2, updated_at = now()
       WHERE email = $3 AND is_active = true
       RETURNING id, email, name`,
      [reset_token, reset_expires, email.toLowerCase()],
    );

    if (rows.length)
      sendPasswordResetEmail(rows[0], reset_token).catch(console.error);

    return res.json({
      message: "If that email exists, a reset link has been sent.",
    });
  } catch (err) {
    console.error("[forgotPassword]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Reset password ────────────────────────────────────────────────────
export const resetPassword = async (req, res) => {
  const { token } = req.params;
  const { password } = req.body;

  if (!token || !password)
    return res.status(400).json({ error: "token and password are required" });
  if (password.length < 8)
    return res
      .status(400)
      .json({ error: "password must be at least 8 characters" });

  try {
    const { rows: tokenRows } = await req.db.query(
      `SELECT id, email FROM users
       WHERE reset_token = $1 AND reset_token_expires > now() AND is_active = true`,
      [token],
    );

    if (!tokenRows.length)
      return res.status(400).json({ error: "invalid or expired reset link" });

    const password_hash = await hashPassword(password);

    await req.db.query(
      `UPDATE users
       SET password_hash         = $1,
           reset_token           = null,
           reset_token_expires   = null,
           updated_at            = now()
       WHERE id = $2`,
      [password_hash, tokenRows[0].id],
    );

    await safeDel(`user:${tokenRows[0].id}`);

    return res.json({
      message: "Password reset successfully. You can now log in.",
    });
  } catch (err) {
    console.error("[resetPassword]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export async function updateProfile(req, res) {
  const { name, phone, country } = req.body;

  const fields = [];
  const params = [];

  if (name !== undefined) {
    const trimmed = name?.trim();
    if (!trimmed || trimmed.length < 2) {
      return res
        .status(400)
        .json({ error: "Name must be at least 2 characters" });
    }
    params.push(trimmed);
    fields.push(`name = $${params.length}`);
  }

  if (phone !== undefined) {
    if (phone && !/^\+?[\d\s\-()]{7,15}$/.test(phone)) {
      return res.status(400).json({ error: "Enter a valid phone number" });
    }
    params.push(phone || null);
    fields.push(`phone = $${params.length}`);
  }

  if (country !== undefined) {
    params.push(country || null);
    fields.push(`country = $${params.length}`);
  }

  if (!fields.length) {
    return res.status(400).json({ error: "No fields to update" });
  }

  params.push(req.user.id);

  try {
    const { rows } = await req.db.query(
      `UPDATE users
       SET ${fields.join(", ")}, updated_at = now()
       WHERE id = $${params.length}
       RETURNING id, name, email, phone, country, avatar, role`,
      params,
    );

    if (!rows.length) {
      return res.status(404).json({ error: "User not found" });
    }

    await safeDel(`user:${req.user.id}`);

    return res.json({ user: rows[0], message: "Profile updated successfully" });
  } catch (err) {
    console.error("[auth/updateProfile]", err);
    return res.status(500).json({ error: "internal server error" });
  }
}

// ADD this to src/controllers/auth.js
// Also add to imports at top: import { uploadMediaToCloudinary } from "../utils/cloudinary-utils.js";

export const uploadAvatar = async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: "No file provided" });
    }

    // 5MB limit
    if (file.size > 5 * 1024 * 1024) {
      return res.status(400).json({
        error: "Image must be under 5MB. Please choose a smaller image.",
      });
    }

    const validTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (!validTypes.includes(file.mimetype)) {
      return res.status(400).json({
        error: "Only JPG, PNG, WebP and GIF are allowed",
      });
    }

    // Upload to Cloudinary
    const { uploadMediaToCloudinary } =
      await import("../utils/cloudinary-utils.js");
    const result = await uploadMediaToCloudinary(
      file.buffer,
      "image",
      `avatars/${req.user.id}`,
    );

    // Update user avatar URL
    const { rows } = await req.db.query(
      `UPDATE users SET avatar = $1, updated_at = now()
       WHERE id = $2
       RETURNING id, name, email, avatar, role, phone, country`,
      [result.url, req.user.id],
    );

    if (!rows.length) {
      return res.status(404).json({ error: "User not found" });
    }

    // Bust cache
    const { safeDel } = await import("../config/redis.js");
    await safeDel(`user:${req.user.id}`);

    return res.json({ user: rows[0], avatar: result.url });
  } catch (err) {
    console.error("[auth/uploadAvatar]", err);
    return res.status(500).json({ error: "Failed to upload avatar" });
  }
};

export const changePassword = async (req, res) => {
  const { current_password, new_password } = req.body;

  if (!current_password || !new_password) {
    return res
      .status(400)
      .json({ error: "current_password and new_password are required" });
  }
  if (new_password.length < 8) {
    return res
      .status(400)
      .json({ error: "password must be at least 8 characters" });
  }

  try {
    const { rows } = await req.db.query(
      `SELECT password_hash, google_id FROM users WHERE id = $1`,
      [req.user.id],
    );

    if (!rows.length) {
      return res.status(404).json({ error: "user not found" });
    }

    const user = rows[0];

    // Google-only account with no password
    if (!user.password_hash) {
      return res.status(400).json({
        error:
          "This account uses Google sign-in and has no password set. Use 'Forgot password' to set one.",
        code: "NO_PASSWORD_SET",
      });
    }

    // Verify current password
    const valid = await verifyPassword(current_password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: "Current password is incorrect" });
    }

    // Hash and save new password
    const new_hash = await hashPassword(new_password);
    await req.db.query(
      `UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2`,
      [new_hash, req.user.id],
    );

    // Bust cache
    await safeDel(`user:${req.user.id}`);

    return res.json({ message: "Password changed successfully" });
  } catch (err) {
    console.error("[auth/changePassword]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export const deleteAccount = async (req, res) => {
  const { password } = req.body;

  try {
    const { rows } = await req.db.query(
      `SELECT password_hash, google_id FROM users WHERE id = $1`,
      [req.user.id],
    );
    if (!rows.length) return res.status(404).json({ error: "user not found" });

    // Require password for email users
    if (rows[0].password_hash && !rows[0].google_id) {
      if (!password)
        return res
          .status(400)
          .json({ error: "password is required to delete your account" });
      const valid = await verifyPassword(password, rows[0].password_hash);
      if (!valid) return res.status(401).json({ error: "incorrect password" });
    }

    // Soft-deactivate
    await req.db.query(
      `UPDATE users SET is_active = false, updated_at = now() WHERE id = $1`,
      [req.user.id],
    );

    // Cancel any active subscriptions
    await req.db.query(
      `UPDATE subscriptions SET status = 'cancelled', cancelled_at = now()
       WHERE user_id = $1 AND status IN ('active','trialing','paused')`,
      [req.user.id],
    );

    await safeDel(`user:${req.user.id}`);

    return res.json({ message: "Account deactivated successfully" });
  } catch (err) {
    console.error("[auth/deleteAccount]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};
