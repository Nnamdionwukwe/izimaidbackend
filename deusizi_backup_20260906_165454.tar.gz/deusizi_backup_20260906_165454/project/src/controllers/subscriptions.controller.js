import { notify } from "../utils/notify.js";
import {
  sendSubscriptionConfirmationEmail,
  sendSubscriptionRenewalEmail,
  sendSubscriptionCancelledEmail,
  sendSubscriptionExpiredEmail,
  sendSubscriptionPaymentFailedEmail,
  sendTrialEndingEmail,
  sendProBadgeActivatedEmail,
} from "../utils/mailer.js";

const FLW_SECRET_KEY = process.env.FLW_SECRET_KEY;
const FLW_SECRET_HASH = process.env.FLW_SECRET_HASH;
const FLW_BASE = "https://api.flutterwave.com/v3";

async function flutterwaveRequest(method, path, body) {
  const res = await fetch(`${FLW_BASE}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${FLW_SECRET_KEY}`,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  return res.json();
}

// ── Helper: get plan by id or name ────────────────────────────────────
async function getPlan(db, planIdOrName) {
  const isUUID =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
      planIdOrName,
    );

  const { rows } = await db.query(
    isUUID
      ? `SELECT * FROM subscription_plans WHERE id = $1::uuid`
      : `SELECT * FROM subscription_plans WHERE name = $1`,
    [planIdOrName],
  );
  return rows[0] || null;
}

// ── Helper: get active subscription for user ──────────────────────────
async function getActiveSub(db, userId) {
  const { rows } = await db.query(
    `SELECT s.*, sp.name as plan_name, sp.display_name, sp.features,
            sp.bookings_per_month, sp.discount_percent, sp.prices,
            sp.priority_matching, sp.dedicated_support, sp.badge
     FROM subscriptions s
     JOIN subscription_plans sp ON sp.id = s.plan_id
     WHERE s.user_id = $1
       AND s.status IN ('active','trialing','past_due','paused')
     ORDER BY s.created_at DESC LIMIT 1`,
    [userId],
  );
  return rows[0] || null;
}

// ── Helper: apply promo code ──────────────────────────────────────────
async function applyPromo(db, code, planName, currency) {
  if (!code) return { discount: 0, promo: null };

  const { rows } = await db.query(
    `SELECT * FROM promo_codes
     WHERE code = $1
       AND is_active = true
       AND (max_uses IS NULL OR uses_count < max_uses)
       AND valid_from <= now()
       AND (valid_until IS NULL OR valid_until >= now())
       AND (currency IS NULL OR currency = $2)`,
    [code.toUpperCase(), currency],
  );

  if (!rows.length)
    return { discount: 0, promo: null, error: "invalid or expired promo code" };

  const promo = rows[0];
  return {
    discount: Number(promo.discount_value),
    type: promo.discount_type,
    promo,
  };
}

// ── Helper: calculate final price with promo ──────────────────────────
function calcFinalPrice(basePrice, discount, discountType) {
  if (!discount) return basePrice;
  if (discountType === "percent") {
    return Math.max(0, basePrice - (basePrice * discount) / 100);
  }
  return Math.max(0, basePrice - discount);
}

// ──────────────────────────────────────────────────────────────────────
//  PUBLIC
// ──────────────────────────────────────────────────────────────────────

// GET /api/subscriptions/plans
export const getPlans = async (req, res) => {
  const { role = "customer", currency = "NGN", interval } = req.query;

  try {
    const conditions = ["is_active = true", "target_role = $1"];
    const params = [role];

    if (interval) {
      params.push(interval);
      conditions.push(`interval = $${params.length}`);
    }

    const { rows } = await req.db.query(
      `SELECT id, name, display_name, description, target_role,
              plan_type, interval, prices, features,
              bookings_per_month, discount_percent, priority_matching,
              dedicated_support, badge, trial_days, is_featured,
              is_popular, sort_order
       FROM subscription_plans
       WHERE ${conditions.join(" AND ")}
       ORDER BY sort_order ASC`,
      params,
    );

    const plans = rows.map((p) => ({
      ...p,
      price: p.prices[currency] || p.prices["USD"] || 0,
      currency,
    }));

    return res.json({ plans });
  } catch (err) {
    console.error("[subscriptions/getPlans]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// GET /api/subscriptions/my
export const getMySubscription = async (req, res) => {
  try {
    const sub = await getActiveSub(req.db, req.user.id);

    if (!sub) {
      const freePlan = await getPlan(req.db, "free");
      return res.json({
        subscription: null,
        plan: freePlan,
        is_free: true,
        bookings_used: 0,
        bookings_limit: 2,
      });
    }

    const { rows: invoices } = await req.db.query(
      `SELECT id, amount, currency, status, period_start, period_end, paid_at, created_at
       FROM subscription_invoices
       WHERE subscription_id = $1
       ORDER BY created_at DESC LIMIT 6`,
      [sub.id],
    );

    return res.json({
      subscription: sub,
      invoices,
      is_free: false,
      bookings_used: sub.bookings_used,
      bookings_limit: sub.bookings_per_month,
    });
  } catch (err) {
    console.error("[subscriptions/getMySubscription]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// POST /api/subscriptions/validate-promo
export const validatePromo = async (req, res) => {
  const { code, plan_name, currency = "NGN" } = req.body;
  if (!code) return res.status(400).json({ error: "code is required" });

  const { discount, type, promo, error } = await applyPromo(
    req.db,
    code,
    plan_name,
    currency,
  );
  if (error) return res.status(400).json({ error });

  return res.json({
    valid: true,
    discount_type: type,
    discount_value: discount,
    discount_percent: type === "percent" ? discount : 0,
    description: promo.description,
  });
};

// ──────────────────────────────────────────────────────────────────────
//  SUBSCRIBE — FLUTTERWAVE (all currencies)
// ──────────────────────────────────────────────────────────────────────

export const subscribeFlutterwave = async (req, res) => {
  const { plan_id, currency = "NGN", promo_code } = req.body;
  if (!plan_id) return res.status(400).json({ error: "plan_id is required" });

  try {
    const plan = await getPlan(req.db, plan_id);
    if (!plan) return res.status(404).json({ error: "plan not found" });

    const existing = await getActiveSub(req.db, req.user.id);
    if (existing) {
      return res.status(409).json({
        error: "you already have an active subscription",
        current_plan: existing.display_name,
      });
    }

    const basePrice = plan.prices[currency] || plan.prices["NGN"] || 0;
    if (basePrice === 0) {
      return await activateFreePlan(req, res, plan);
    }

    const {
      discount,
      type: discountType,
      promo,
      error: promoErr,
    } = await applyPromo(req.db, promo_code, plan.name, currency);
    if (promo_code && promoErr)
      return res.status(400).json({ error: promoErr });

    const finalPrice = calcFinalPrice(basePrice, discount, discountType);

    const { rows: userRows } = await req.db.query(
      `SELECT name, email FROM users WHERE id = $1`,
      [req.user.id],
    );
    const user = userRows[0];

    const tx_ref = `ds_sub_${req.user.id.slice(0, 8)}_${Date.now()}`;

    const payload = {
      tx_ref,
      amount: finalPrice,
      currency,
      redirect_url: `${process.env.CLIENT_URL}/subscription/verify?gateway=flutterwave`,
      customer: {
        email: user.email,
        name: user.name,
      },
      customizations: {
        title: `${plan.display_name} Subscription`,
        description: `${plan.display_name} — ${plan.interval} plan`,
        logo: process.env.LOGO_URL,
      },
      meta: {
        user_id: req.user.id,
        plan_id: plan.id,
        plan_name: plan.name,
        currency,
        promo_code: promo_code || null,
      },
    };

    const flutterwaveRes = await flutterwaveRequest(
      "POST",
      "/payments",
      payload,
    );
    console.log(
      "[subscribeFlutterwave] Response:",
      JSON.stringify(flutterwaveRes, null, 2),
    );

    if (flutterwaveRes.status !== "success") {
      return res.status(502).json({
        error: "Flutterwave initialization failed",
        details: flutterwaveRes.message,
      });
    }

    const link = flutterwaveRes.data.link;

    // ── Store metadata in notes column ──
    const notes = JSON.stringify({
      user_id: req.user.id,
      plan_id: plan.id,
      plan_name: plan.name,
      currency,
      promo_code: promo_code || null,
    });

    await req.db.query(
      `INSERT INTO payments
         (booking_id, customer_id, amount, currency, gateway,
          flutterwave_tx_ref, flutterwave_payment_id, status, notes)
       VALUES (NULL, $1, $2, $3, 'flutterwave', $4, NULL, 'pending', $5)
       RETURNING id`,
      [req.user.id, finalPrice, currency, tx_ref, notes],
    );

    return res.json({
      gateway: "flutterwave",
      link,
      tx_ref,
    });
  } catch (err) {
    console.error("[subscriptions/subscribeFlutterwave]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ──────────────────────────────────────────────────────────────────────
//  ACTIVATE FREE PLAN (internal helper)
// ──────────────────────────────────────────────────────────────────────

async function activateFreePlan(req, res, plan) {
  const now = new Date();
  const expiry = new Date(now);
  expiry.setMonth(expiry.getMonth() + 1);

  const { rows } = await req.db.query(
    `INSERT INTO subscriptions
       (user_id, plan_id, status, currency, amount, interval,
        current_period_start, current_period_end, gateway, auto_renew)
     VALUES ($1,$2,'active','NGN',0,'monthly',$3,$4,'manual',true)
     RETURNING *`,
    [req.user.id, plan.id, now, expiry],
  );

  await req.db.query(`UPDATE users SET subscription_plan = $1 WHERE id = $2`, [
    plan.name,
    req.user.id,
  ]);

  return res.status(201).json({
    message: "Free plan activated",
    subscription: rows[0],
    plan,
  });
}

// ── Internal: activate subscription in DB ────────────────────────────
async function activateSubscription(
  db,
  {
    userId,
    planId,
    currency,
    amount,
    gateway,
    flutterwave_tx_ref,
    flutterwave_transaction_id,
    promoCode,
    interval,
    trial_end,
  },
) {
  const plan = await getPlan(db, planId);

  // Cancel any existing subscription
  await db.query(
    `UPDATE subscriptions
     SET status = 'cancelled', cancelled_at = now(), cancel_at_period_end = false
     WHERE user_id = $1 AND status IN ('active','trialing','past_due','paused')`,
    [userId],
  );

  const now = new Date();
  const normalizedInterval =
    interval === "year"
      ? "annual"
      : interval === "month"
        ? "monthly"
        : interval === "quarter"
          ? "quarterly"
          : "monthly";

  const periodMonths =
    normalizedInterval === "annual"
      ? 12
      : normalizedInterval === "quarterly"
        ? 3
        : 1;

  const expiry = new Date(now);
  expiry.setMonth(expiry.getMonth() + periodMonths);

  const status = trial_end ? "trialing" : "active";

  const { rows } = await db.query(
    `INSERT INTO subscriptions (
      user_id, plan_id, status, currency, amount, interval,
      current_period_start, current_period_end,
      trial_start, trial_end,
      gateway, flutterwave_tx_ref, flutterwave_transaction_id,
      promo_code, discount_percent, auto_renew
    ) VALUES (
      $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
      $11,$12,$13,$14,$15,true
    ) RETURNING *`,
    [
      userId,
      planId,
      status,
      currency,
      amount,
      normalizedInterval,
      now,
      expiry,
      trial_end ? now : null,
      trial_end || null,
      gateway,
      flutterwave_tx_ref || null,
      flutterwave_transaction_id || null,
      promoCode || null,
      0,
    ],
  );

  // Create invoice
  await db.query(
    `INSERT INTO subscription_invoices
       (subscription_id, user_id, amount, currency, status, gateway,
        period_start, period_end, paid_at)
     VALUES ($1,$2,$3,$4,'paid',$5,$6,$7,now())`,
    [rows[0].id, userId, amount, currency, gateway, now, expiry],
  );

  // Update user subscription plan + badge
  await db.query(
    `UPDATE users
     SET subscription_plan = $1, subscription_badge = $2
     WHERE id = $3`,
    [plan.name, plan.badge, userId],
  );

  if (plan.name === "pro_badge") {
    const { rows: maidRows } = await db.query(
      `SELECT name, email FROM users WHERE id = $1`,
      [userId],
    );
    if (maidRows.length) {
      sendProBadgeActivatedEmail(maidRows[0]).catch(console.error);
    }
  }

  return rows[0];
}

// ──────────────────────────────────────────────────────────────────────
//  VERIFY PAYMENT & ACTIVATE SUBSCRIPTION (with fallback)
// ──────────────────────────────────────────────────────────────────────

export const verifySubscriptionPayment = async (req, res) => {
  const { gateway, reference, transaction_id } = req.query;
  const userId = req.user.id;

  console.log("[verify] Received:", {
    gateway,
    reference,
    transaction_id,
    userId,
  });

  try {
    if (gateway !== "flutterwave") {
      return res.status(400).json({ error: "only flutterwave is supported" });
    }

    let payment = null;

    // 1. Try by flutterwave_tx_ref
    if (reference) {
      const { rows } = await req.db.query(
        `SELECT * FROM payments WHERE flutterwave_tx_ref = $1`,
        [reference],
      );
      if (rows.length) payment = rows[0];
    }

    // 2. Try by flutterwave_payment_id
    if (!payment && transaction_id) {
      const { rows } = await req.db.query(
        `SELECT * FROM payments WHERE flutterwave_payment_id = $1`,
        [transaction_id],
      );
      if (rows.length) payment = rows[0];
    }

    // 3. Fallback: most recent pending payment for this user
    if (!payment) {
      const { rows } = await req.db.query(
        `SELECT * FROM payments 
         WHERE customer_id = $1 
           AND gateway = 'flutterwave' 
           AND status = 'pending'
         ORDER BY created_at DESC LIMIT 1`,
        [userId],
      );
      if (rows.length) {
        payment = rows[0];
        console.log("[verify] Fallback found payment:", payment.id);
      }
    }

    if (!payment) {
      console.error("[verify] No payment found for any method");
      return res.status(404).json({ error: "payment not found" });
    }

    console.log(
      "[verify] Found payment:",
      payment.id,
      "status:",
      payment.status,
    );

    // Delegate to helper
    return handlePayment(payment, req, res);
  } catch (err) {
    console.error("[subscriptions/verifySubscriptionPayment]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ── Helper to handle a found payment ──────────────────────────────
async function handlePayment(payment, req, res) {
  console.log("[handlePayment] Payment record:", {
    id: payment.id,
    status: payment.status,
    flutterwave_tx_ref: payment.flutterwave_tx_ref,
  });

  if (payment.status === "success") {
    const sub = await getActiveSub(req.db, payment.customer_id);
    const plan = sub ? await getPlan(req.db, sub.plan_id) : null;
    return res.json({
      message: "Payment already verified",
      subscription: sub,
      plan,
    });
  }

  if (payment.status === "failed" || payment.status === "cancelled") {
    return res.status(400).json({ error: `Payment ${payment.status}` });
  }

  if (!payment.flutterwave_tx_ref) {
    console.error("[handlePayment] Missing flutterwave_tx_ref");
    return res
      .status(500)
      .json({ error: "Missing payment reference. Please contact support." });
  }

  // ── Verify with Flutterwave ──
  const verifyRes = await flutterwaveRequest(
    "GET",
    `/transactions/verify_by_reference?tx_ref=${payment.flutterwave_tx_ref}`,
  );

  console.log("[handlePayment] Verify response:", verifyRes);

  if (verifyRes.status !== "success" || !verifyRes.data) {
    return res
      .status(500)
      .json({ error: "Could not verify payment. Please contact support." });
  }

  const fwStatus = verifyRes.data.status;

  if (fwStatus === "successful") {
    // ── Extract metadata: try notes first, then fallback to Flutterwave's meta ──
    let meta = {};
    if (payment.notes) {
      try {
        meta = JSON.parse(payment.notes);
        console.log("[handlePayment] Parsed notes:", meta);
      } catch (e) {
        console.error("[handlePayment] Error parsing notes:", e);
      }
    }

    // Fallback: use meta from Flutterwave response if notes empty
    if (!meta || Object.keys(meta).length === 0) {
      const fwMeta = verifyRes.data.meta || {};
      console.log("[handlePayment] Using Flutterwave meta:", fwMeta);
      meta = {
        user_id: fwMeta.user_id || payment.customer_id,
        plan_id: fwMeta.plan_id,
        promo_code: fwMeta.promo_code || null,
      };
    }

    // Final fallback: use payment.customer_id as user_id
    if (!meta.user_id) meta.user_id = payment.customer_id;

    const userId = meta.user_id;
    const planId = meta.plan_id;

    if (!userId || !planId) {
      console.error("[handlePayment] Missing metadata:", {
        userId,
        planId,
        meta,
      });
      return res.status(400).json({ error: "missing subscription metadata" });
    }

    const plan = await getPlan(req.db, planId);
    if (!plan) return res.status(404).json({ error: "plan not found" });

    try {
      // ── Activate subscription ──
      await activateSubscription(req.db, {
        userId,
        planId: plan.id,
        currency: payment.currency,
        amount: payment.amount,
        gateway: "flutterwave",
        flutterwave_tx_ref: payment.flutterwave_tx_ref,
        flutterwave_transaction_id: verifyRes.data.id,
        promoCode: meta.promo_code,
        interval: plan.interval,
        trial_end:
          plan.trial_days > 0
            ? new Date(Date.now() + plan.trial_days * 86400000)
            : null,
      });

      await req.db.query(
        `UPDATE payments SET status = 'success', paid_at = now() WHERE id = $1`,
        [payment.id],
      );

      // ── Send notifications ──
      const sub = await getActiveSub(req.db, userId);
      const { rows: userRows } = await req.db.query(
        `SELECT name, email FROM users WHERE id = $1`,
        [userId],
      );
      const user = userRows[0];

      if (user) {
        await notify(req.db, {
          userId,
          type: "payment_received",
          title: `${plan.display_name} subscription activated 🎉`,
          body: `Your ${plan.display_name} subscription is now active. Enjoy your benefits!`,
          priority: "high",
          action_url: "/settings",
          data: {
            plan_name: plan.name,
            plan_id: planId,
            amount: sub?.amount || payment.amount,
            currency: sub?.currency || payment.currency,
          },
          sendMail: () => sendSubscriptionConfirmationEmail(user, plan, sub),
        });

        if (plan.name === "pro_badge" || plan.name?.includes("pro")) {
          sendProBadgeActivatedEmail(user).catch(console.error);
        }

        if (sub?.trial_end) {
          const daysToTrialEnd = Math.ceil(
            (new Date(sub.trial_end) - Date.now()) / 86400000,
          );
          if (daysToTrialEnd <= 3 && daysToTrialEnd > 0) {
            sendTrialEndingEmail(user, plan, daysToTrialEnd).catch(
              console.error,
            );
          }
        }
      }

      if (meta.promo_code) {
        await req.db.query(
          `UPDATE promo_codes SET uses_count = uses_count + 1 WHERE code = $1`,
          [meta.promo_code.toUpperCase()],
        );
      }

      return res.json({
        message: "Subscription activated",
        subscription: sub,
        plan,
      });
    } catch (err) {
      console.error("[handlePayment] Activation error:", err);
      return res.status(500).json({ error: "Failed to activate subscription" });
    }
  } else if (fwStatus === "pending") {
    await req.db.query(`UPDATE payments SET status = 'pending' WHERE id = $1`, [
      payment.id,
    ]);
    return res.json({
      message:
        "Payment is pending confirmation. We'll notify you once confirmed.",
      status: "pending",
    });
  } else {
    await req.db.query(`UPDATE payments SET status = 'failed' WHERE id = $1`, [
      payment.id,
    ]);
    return res.status(402).json({ error: "Payment was not successful" });
  }
}

// ──────────────────────────────────────────────────────────────────────
//  CANCEL SUBSCRIPTION
// ──────────────────────────────────────────────────────────────────────

export const cancelSubscription = async (req, res) => {
  const { reason, immediate = false } = req.body;

  try {
    const sub = await getActiveSub(req.db, req.user.id);
    if (!sub) return res.status(404).json({ error: "no active subscription" });

    const plan = await getPlan(req.db, sub.plan_id);

    if (immediate) {
      await req.db.query(
        `UPDATE subscriptions
         SET status = 'cancelled', cancelled_at = now(),
             cancel_at_period_end = false, cancellation_reason = $1
         WHERE id = $2`,
        [reason || null, sub.id],
      );
      await req.db.query(
        `UPDATE users SET subscription_plan = 'free', subscription_badge = null WHERE id = $1`,
        [req.user.id],
      );
    } else {
      await req.db.query(
        `UPDATE subscriptions
         SET cancel_at_period_end = true, cancelled_at = now(),
             cancellation_reason = $1
         WHERE id = $2`,
        [reason || null, sub.id],
      );
    }

    // Cancel on Flutterwave (if we have a transaction reference)
    if (sub.flutterwave_transaction_id) {
      try {
        // Flutterwave doesn't have a direct "cancel subscription" endpoint;
        // we would need to use their recurring payment feature.
        // For now, we just update the DB. The user will not be charged again.
        // If we used Flutterwave's tokenization for recurring, we could disable it.
        // We'll skip external cancellation since we only used one-time payment.
        console.log("Flutterwave subscription cancellation not implemented");
      } catch (err) {
        console.error(
          "[subscriptions/cancel] Flutterwave cancel failed:",
          err.message,
        );
      }
    }

    const { rows: userRows } = await req.db.query(
      `SELECT name, email FROM users WHERE id = $1`,
      [req.user.id],
    );

    await notify(req.db, {
      userId: req.user.id,
      type: "payment_receipt",
      title: "Subscription cancelled",
      body: immediate
        ? "Your subscription has been cancelled immediately."
        : `Your subscription will remain active until ${new Date(sub.current_period_end).toDateString()}.`,
      action_url: "/pricing",
      sendMail: () =>
        sendSubscriptionCancelledEmail(userRows[0], plan, {
          ...sub,
          cancel_at_period_end: !immediate,
          cancellation_reason: reason,
        }),
    });

    const { safeDel } = await import("../config/redis.js");
    await safeDel(`user:${req.user.id}`);

    return res.json({
      message: immediate
        ? "Subscription cancelled immediately."
        : `Subscription will end on ${new Date(sub.current_period_end).toDateString()}.`,
      cancel_at_period_end: !immediate,
      period_end: sub.current_period_end,
    });
  } catch (err) {
    console.error("[subscriptions/cancelSubscription]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ──────────────────────────────────────────────────────────────────────
//  PAUSE / RESUME (unchanged)
// ──────────────────────────────────────────────────────────────────────

export const pauseSubscription = async (req, res) => {
  try {
    const sub = await getActiveSub(req.db, req.user.id);
    if (!sub || sub.status !== "active") {
      return res.status(404).json({ error: "no active subscription to pause" });
    }

    await req.db.query(
      `UPDATE subscriptions SET status = 'paused', paused_at = now()
       WHERE id = $1`,
      [sub.id],
    );

    await notify(req.db, {
      userId: req.user.id,
      type: "payment_receipt",
      title: "Subscription paused",
      body: "Your subscription has been paused. Resume anytime.",
      action_url: "/settings/subscription",
    });

    return res.json({ message: "Subscription paused" });
  } catch (err) {
    console.error("[subscriptions/pauseSubscription]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export const resumeSubscription = async (req, res) => {
  try {
    const { rows: subRows } = await req.db.query(
      `SELECT * FROM subscriptions WHERE user_id = $1 AND status = 'paused'
       ORDER BY created_at DESC LIMIT 1`,
      [req.user.id],
    );
    if (!subRows.length)
      return res.status(404).json({ error: "no paused subscription" });

    const sub = subRows[0];
    const daysPaused = Math.ceil(
      (Date.now() - new Date(sub.paused_at).getTime()) / (1000 * 60 * 60 * 24),
    );
    const newExpiry = new Date(sub.current_period_end);
    newExpiry.setDate(newExpiry.getDate() + daysPaused);

    await req.db.query(
      `UPDATE subscriptions
       SET status = 'active', resumed_at = now(), current_period_end = $1
       WHERE id = $2`,
      [newExpiry, sub.id],
    );

    await notify(req.db, {
      userId: req.user.id,
      type: "payment_received",
      title: "Subscription resumed",
      body: `Your subscription is active again. It's been extended to ${newExpiry.toDateString()}.`,
      action_url: "/settings/subscription",
    });

    return res.json({ message: "Subscription resumed", new_expiry: newExpiry });
  } catch (err) {
    console.error("[subscriptions/resumeSubscription]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ──────────────────────────────────────────────────────────────────────
//  UPGRADE / DOWNGRADE
// ──────────────────────────────────────────────────────────────────────

export const changePlan = async (req, res) => {
  const { new_plan_id, promo_code } = req.body;
  if (!new_plan_id)
    return res.status(400).json({ error: "new_plan_id is required" });

  try {
    const currentSub = await getActiveSub(req.db, req.user.id);
    const newPlan = await getPlan(req.db, new_plan_id);
    if (!newPlan) return res.status(404).json({ error: "plan not found" });

    if (currentSub && currentSub.plan_id === newPlan.id) {
      return res.status(409).json({ error: "already on this plan" });
    }

    const currency = "NGN"; // or use user's preferred currency
    const basePrice = newPlan.prices[currency] || newPlan.prices["NGN"] || 0;

    // Free plan — switch directly
    if (basePrice === 0) {
      await req.db.query(
        `UPDATE subscriptions SET plan_id = $1, updated_at = now() WHERE id = $2`,
        [newPlan.id, currentSub?.id],
      );
      await req.db.query(
        `UPDATE users SET subscription_plan = $1, subscription_badge = $2 WHERE id = $3`,
        [newPlan.name, newPlan.badge, req.user.id],
      );
      return res.json({
        message: `Switched to ${newPlan.display_name}`,
        plan: newPlan,
      });
    }

    // Paid plan – cancel current and create new payment
    if (currentSub) {
      await req.db.query(
        `UPDATE subscriptions
         SET status = 'cancelled', cancelled_at = now(), updated_at = now()
         WHERE user_id = $1 AND status IN ('active','trialing','past_due')`,
        [req.user.id],
      );
      await req.db.query(
        `UPDATE users SET subscription_plan = 'free', subscription_badge = null WHERE id = $1`,
        [req.user.id],
      );
    }

    // Delegate to subscribe handler
    req.body.plan_id = new_plan_id;
    req.body.currency = currency;
    req.body.promo_code = promo_code;

    return subscribeFlutterwave(req, res);
  } catch (err) {
    console.error("[subscriptions/changePlan]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

// ──────────────────────────────────────────────────────────────────────
//  WEBHOOK (FLUTTERWAVE)
// ──────────────────────────────────────────────────────────────────────

export const flutterwaveSubscriptionWebhook = async (req, res) => {
  const signature = req.headers["verif-hash"];
  if (!signature || signature !== FLW_SECRET_HASH) {
    return res.status(401).json({ error: "invalid signature" });
  }

  const { event, data } = req.body;

  try {
    if (event !== "charge.completed") {
      return res.sendStatus(200);
    }

    const tx_ref = data.tx_ref;
    const status = data.status;

    // Find the payment record
    const { rows: paymentRows } = await req.db.query(
      `SELECT id, customer_id, amount, currency, notes FROM payments
       WHERE flutterwave_tx_ref = $1 AND status = 'pending'`,
      [tx_ref],
    );

    if (!paymentRows.length) {
      console.warn(`Payment record not found for tx_ref: ${tx_ref}`);
      return res.sendStatus(200);
    }

    const payment = paymentRows[0];
    const meta = payment.notes ? JSON.parse(payment.notes) : {};

    if (status === "successful") {
      const userId = meta.user_id || payment.customer_id;
      const planId = meta.plan_id;

      if (!userId || !planId) {
        console.error("Missing metadata for subscription activation");
        return res.sendStatus(500);
      }

      const plan = await getPlan(req.db, planId);
      if (!plan) {
        console.error("Plan not found:", planId);
        return res.sendStatus(500);
      }

      // Activate subscription
      await activateSubscription(req.db, {
        userId,
        planId: plan.id,
        currency: payment.currency,
        amount: payment.amount,
        gateway: "flutterwave",
        flutterwave_tx_ref: tx_ref,
        flutterwave_transaction_id: data.id,
        promoCode: meta.promo_code,
        interval: plan.interval,
        trial_end:
          plan.trial_days > 0
            ? new Date(Date.now() + plan.trial_days * 86400000)
            : null,
      });

      // Update payment status
      await req.db.query(
        `UPDATE payments SET status = 'success', paid_at = now() WHERE id = $1`,
        [payment.id],
      );

      // Notifications
      const sub = await getActiveSub(req.db, userId);
      const { rows: userRows } = await req.db.query(
        `SELECT name, email FROM users WHERE id = $1`,
        [userId],
      );
      const user = userRows[0];

      if (user) {
        await notify(req.db, {
          userId,
          type: "payment_received",
          title: `${plan.display_name} subscription activated 🎉`,
          body: `Your ${plan.display_name} subscription is now active. Enjoy your benefits!`,
          priority: "high",
          action_url: "/settings",
          data: {
            plan_name: plan.name,
            plan_id: planId,
            amount: sub?.amount || payment.amount,
            currency: sub?.currency || payment.currency,
          },
          sendMail: () => sendSubscriptionConfirmationEmail(user, plan, sub),
        });

        if (plan.name === "pro_badge" || plan.name?.includes("pro")) {
          sendProBadgeActivatedEmail(user).catch(console.error);
        }

        if (sub?.trial_end) {
          const daysToTrialEnd = Math.ceil(
            (new Date(sub.trial_end) - Date.now()) / 86400000,
          );
          if (daysToTrialEnd <= 3 && daysToTrialEnd > 0) {
            sendTrialEndingEmail(user, plan, daysToTrialEnd).catch(
              console.error,
            );
          }
        }
      }

      if (meta.promo_code) {
        await req.db.query(
          `UPDATE promo_codes SET uses_count = uses_count + 1 WHERE code = $1`,
          [meta.promo_code.toUpperCase()],
        );
      }
    } else {
      // Failed or cancelled
      await req.db.query(`UPDATE payments SET status = $1 WHERE id = $2`, [
        status === "cancelled" ? "cancelled" : "failed",
        payment.id,
      ]);
    }

    return res.sendStatus(200);
  } catch (err) {
    console.error("[subscriptions/flutterwaveWebhook]", err);
    return res.sendStatus(500);
  }
};

// ──────────────────────────────────────────────────────────────────────
//  ADMIN FUNCTIONS – unchanged (gateway-agnostic)
// ──────────────────────────────────────────────────────────────────────

export const adminGetSubscriptions = async (req, res) => {
  const { status, plan_name, page = 1, limit = 50 } = req.query;
  const offset = (Number(page) - 1) * Number(limit);
  const conditions = [];
  const params = [];

  if (status) {
    params.push(status);
    conditions.push(`s.status = $${params.length}`);
  }
  if (plan_name) {
    params.push(plan_name);
    conditions.push(`sp.name = $${params.length}`);
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  params.push(Number(limit), offset);

  try {
    const { rows } = await req.db.query(
      `SELECT s.*,
              u.name as user_name, u.email as user_email, u.role as user_role,
              sp.display_name as plan_display_name, sp.name as plan_name,
              sp.prices, sp.badge
       FROM subscriptions s
       JOIN users u ON u.id = s.user_id
       JOIN subscription_plans sp ON sp.id = s.plan_id
       ${where}
       ORDER BY s.created_at DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params,
    );

    const { rows: summary } = await req.db.query(`
      SELECT s.status, COUNT(*) as count,
             COALESCE(SUM(s.amount), 0) as mrr
      FROM subscriptions s
      WHERE s.status IN ('active','trialing')
      GROUP BY s.status
    `);

    return res.json({ subscriptions: rows, summary });
  } catch (err) {
    console.error("[subscriptions/adminGetSubscriptions]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export const adminGrantSubscription = async (req, res) => {
  const { user_id, plan_id, months = 1, reason } = req.body;
  if (!user_id || !plan_id) {
    return res.status(400).json({ error: "user_id and plan_id are required" });
  }

  try {
    const plan = await getPlan(req.db, plan_id);
    if (!plan) return res.status(404).json({ error: "plan not found" });

    const { rows: userRows } = await req.db.query(
      `SELECT * FROM users WHERE id = $1`,
      [user_id],
    );
    if (!userRows.length)
      return res.status(404).json({ error: "user not found" });

    await req.db.query(
      `UPDATE subscriptions
       SET status = 'cancelled', cancelled_at = now()
       WHERE user_id = $1 AND status IN ('active','trialing','paused')`,
      [user_id],
    );

    const now = new Date();
    const expiry = new Date(now);
    expiry.setMonth(expiry.getMonth() + Number(months));

    await req.db.query(
      `INSERT INTO subscriptions
         (user_id, plan_id, status, currency, amount, interval,
          current_period_start, current_period_end, gateway, auto_renew)
       VALUES ($1,$2,'active','NGN',0,'monthly',$3,$4,'manual',false)`,
      [user_id, plan.id, now, expiry],
    );

    await req.db.query(
      `UPDATE users SET subscription_plan = $1, subscription_badge = $2 WHERE id = $3`,
      [plan.name, plan.badge, user_id],
    );

    if (plan.name === "pro_badge") {
      await req.db.query(
        `UPDATE maid_profiles SET id_verified = true WHERE user_id = $1`,
        [user_id],
      );
    }

    await notify(req.db, {
      userId: user_id,
      type: "payment_received",
      title: `${plan.display_name} subscription granted`,
      body: `An admin has granted you a ${plan.display_name} subscription for ${months} month(s).${reason ? ` Reason: ${reason}` : ""}`,
      priority: "high",
      action_url: "/settings/subscription",
      sendMail: () =>
        sendSubscriptionConfirmationEmail(userRows[0], plan, {
          currency: "NGN",
          amount: 0,
          interval: "monthly",
          current_period_start: now,
          current_period_end: expiry,
        }),
    });

    return res.json({
      message: `${plan.display_name} granted for ${months} month(s)`,
    });
  } catch (err) {
    console.error("[subscriptions/adminGrantSubscription]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export const adminManagePlans = async (req, res) => {
  const { action } = req.body;

  const toIntOrNull = (v) =>
    v !== undefined && v !== null && v !== "" && v !== "null"
      ? parseInt(v, 10)
      : null;

  const toStrOrNull = (v) =>
    v !== undefined && v !== null && v !== "" && v !== "null"
      ? String(v)
      : null;

  const toBool = (v, fallback = false) => {
    if (v === true || v === "true") return true;
    if (v === false || v === "false") return false;
    return fallback;
  };

  try {
    if (action === "create") {
      const {
        name,
        display_name,
        description,
        target_role = "customer",
        plan_type = "recurring",
        interval = "monthly",
        prices,
        features,
        bookings_per_month,
        discount_percent = 0,
        priority_matching = false,
        dedicated_support = false,
        badge,
        trial_days = 0,
        sort_order = 0,
      } = req.body;

      if (!name || !display_name || !prices) {
        return res
          .status(400)
          .json({ error: "name, display_name and prices are required" });
      }

      const { rows } = await req.db.query(
        `INSERT INTO subscription_plans
           (name, display_name, description, target_role, plan_type, interval,
            prices, features, bookings_per_month, discount_percent,
            priority_matching, dedicated_support, badge, trial_days, sort_order)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
         RETURNING *`,
        [
          name,
          display_name,
          toStrOrNull(description),
          target_role,
          plan_type,
          interval,
          JSON.stringify(prices),
          JSON.stringify(features || []),
          toIntOrNull(bookings_per_month),
          Number(discount_percent) || 0,
          toBool(priority_matching),
          toBool(dedicated_support),
          toStrOrNull(badge),
          Number(trial_days) || 0,
          Number(sort_order) || 0,
        ],
      );
      return res.status(201).json({ plan: rows[0] });
    }

    if (action === "update") {
      const { plan_id, ...updates } = req.body;
      if (!plan_id) return res.status(400).json({ error: "plan_id required" });

      const intCols = new Set([
        "bookings_per_month",
        "discount_percent",
        "trial_days",
        "sort_order",
      ]);
      const strNullCols = new Set(["badge", "description"]);
      const boolCols = new Set([
        "priority_matching",
        "dedicated_support",
        "is_featured",
      ]);
      const jsonCols = new Set(["prices", "features"]);

      const allowed = [
        "display_name",
        "description",
        "prices",
        "features",
        "bookings_per_month",
        "discount_percent",
        "priority_matching",
        "dedicated_support",
        "badge",
        "trial_days",
        "sort_order",
        "is_featured",
      ];

      const fields = [];
      const params = [];

      for (const key of allowed) {
        if (updates[key] === undefined) continue;

        let value;
        if (intCols.has(key)) {
          value = toIntOrNull(updates[key]);
        } else if (strNullCols.has(key)) {
          value = toStrOrNull(updates[key]);
        } else if (boolCols.has(key)) {
          value = toBool(updates[key]);
        } else if (jsonCols.has(key)) {
          value =
            typeof updates[key] === "object"
              ? JSON.stringify(updates[key])
              : updates[key];
        } else {
          value = updates[key];
        }

        params.push(value);
        fields.push(`${key} = $${params.length}`);
      }

      if (!fields.length)
        return res.status(400).json({ error: "no fields to update" });

      params.push(plan_id);

      const { rows } = await req.db.query(
        `UPDATE subscription_plans
         SET ${fields.join(", ")}, updated_at = now()
         WHERE id = $${params.length}
         RETURNING *`,
        params,
      );
      return res.json({ plan: rows[0] });
    }

    if (action === "toggle") {
      const { plan_id } = req.body;
      if (!plan_id) return res.status(400).json({ error: "plan_id required" });

      const { rows } = await req.db.query(
        `UPDATE subscription_plans
         SET is_active = NOT is_active, updated_at = now()
         WHERE id = $1
         RETURNING id, name, is_active`,
        [plan_id],
      );
      return res.json({ plan: rows[0] });
    }

    return res
      .status(400)
      .json({ error: "action must be create, update, or toggle" });
  } catch (err) {
    console.error("[subscriptions/adminManagePlans]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export const adminManagePromoCodes = async (req, res) => {
  const { action } = req.body;

  try {
    if (action === "create") {
      const {
        code,
        description,
        discount_type = "percent",
        discount_value,
        currency,
        max_uses,
        min_plan,
        valid_from,
        valid_until,
      } = req.body;

      if (!code || !discount_value) {
        return res
          .status(400)
          .json({ error: "code and discount_value are required" });
      }

      const { rows } = await req.db.query(
        `INSERT INTO promo_codes
           (code, description, discount_type, discount_value, currency,
            max_uses, min_plan, valid_from, valid_until, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
         RETURNING *`,
        [
          code.toUpperCase(),
          description || null,
          discount_type,
          discount_value,
          currency || null,
          max_uses || null,
          min_plan || null,
          valid_from || new Date(),
          valid_until || null,
          req.user.id,
        ],
      );
      return res.status(201).json({ promo: rows[0] });
    }

    if (action === "list") {
      const { rows } = await req.db.query(
        `SELECT * FROM promo_codes ORDER BY created_at DESC`,
      );
      return res.json({ promos: rows });
    }

    if (action === "toggle") {
      const { promo_id } = req.body;
      const { rows } = await req.db.query(
        `UPDATE promo_codes SET is_active = NOT is_active WHERE id = $1
         RETURNING id, code, is_active`,
        [promo_id],
      );
      return res.json({ promo: rows[0] });
    }

    return res
      .status(400)
      .json({ error: "action must be create, list, or toggle" });
  } catch (err) {
    console.error("[subscriptions/adminManagePromoCodes]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export const getSubscriptionAnalytics = async (req, res) => {
  try {
    const [
      mrrByCurrency,
      planBreakdown,
      churnRate,
      recentSignups,
      invoiceStats,
    ] = await Promise.all([
      req.db.query(`
          SELECT
            COALESCE(currency, 'USD')                                          AS currency,
            COALESCE(SUM(amount) FILTER (WHERE status = 'active'),    0)       AS mrr,
            COALESCE(SUM(amount) FILTER (WHERE status = 'trialing'),  0)       AS trial_mrr,
            COUNT(*) FILTER (WHERE status = 'active')                          AS active_count,
            COUNT(*) FILTER (WHERE status = 'trialing')                        AS trial_count,
            COUNT(*) FILTER (WHERE status = 'cancelled')                       AS cancelled_count,
            COUNT(*) FILTER (WHERE status = 'past_due')                        AS past_due_count
          FROM subscriptions
          GROUP BY COALESCE(currency, 'USD')
          ORDER BY mrr DESC
        `),

      req.db.query(`
          SELECT sp.display_name, sp.name, s.status,
                 COUNT(*) as count,
                 COALESCE(SUM(s.amount), 0) as total_revenue
          FROM subscriptions s
          JOIN subscription_plans sp ON sp.id = s.plan_id
          GROUP BY sp.display_name, sp.name, s.status
          ORDER BY count DESC
        `),

      req.db.query(`
          SELECT
            COUNT(*) FILTER (WHERE status = 'cancelled'
              AND cancelled_at >= now() - INTERVAL '30 days') AS churned_30d,
            COUNT(*) FILTER (WHERE status = 'active')          AS active_total
          FROM subscriptions
        `),

      req.db.query(`
          SELECT DATE(s.created_at) as date,
                 COALESCE(s.currency, 'USD') AS currency,
                 COUNT(*) as count,
                 COALESCE(SUM(s.amount), 0) as revenue
          FROM subscriptions s
          WHERE s.created_at >= now() - INTERVAL '30 days'
            AND s.status IN ('active','trialing')
          GROUP BY DATE(s.created_at), COALESCE(s.currency, 'USD')
          ORDER BY date ASC
        `),

      req.db.query(`
          SELECT si.status,
                 COALESCE(si.currency, 'USD') AS currency,
                 COUNT(*) as count,
                 COALESCE(SUM(si.amount), 0) as total
          FROM subscription_invoices si
          WHERE si.created_at >= now() - INTERVAL '30 days'
          GROUP BY si.status, COALESCE(si.currency, 'USD')
          ORDER BY si.status, currency
        `),
    ]);

    const churn = churnRate.rows[0];
    const churnPercent =
      churn.active_total > 0
        ? ((churn.churned_30d / churn.active_total) * 100).toFixed(2)
        : 0;

    return res.json({
      mrr_by_currency: mrrByCurrency.rows,
      plan_breakdown: planBreakdown.rows,
      churn_rate_30d: `${churnPercent}%`,
      recent_signups: recentSignups.rows,
      invoice_stats: invoiceStats.rows,
    });
  } catch (err) {
    console.error("[subscriptions/getSubscriptionAnalytics]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};

export const adminUpdateSubscription = async (req, res) => {
  const { id } = req.params;
  const {
    status,
    plan_id,
    current_period_end,
    cancel_at_period_end,
    auto_renew,
    notes,
  } = req.body;

  const VALID_STATUSES = [
    "active",
    "trialing",
    "past_due",
    "paused",
    "cancelled",
  ];
  if (status && !VALID_STATUSES.includes(status)) {
    return res
      .status(400)
      .json({ error: `status must be one of: ${VALID_STATUSES.join(", ")}` });
  }

  try {
    const { rows: existing } = await req.db.query(
      `SELECT s.*, u.name as user_name, sp.name as plan_name
       FROM subscriptions s
       JOIN users u ON u.id = s.user_id
       JOIN subscription_plans sp ON sp.id = s.plan_id
       WHERE s.id = $1`,
      [id],
    );
    if (!existing.length)
      return res.status(404).json({ error: "subscription not found" });

    const sub = existing[0];
    const fields = ["updated_at = now()"];
    const params = [];

    if (status !== undefined) {
      params.push(status);
      fields.push(`status = $${params.length}`);
      if (status === "cancelled" && sub.status !== "cancelled") {
        fields.push("cancelled_at = now()");
      }
    }
    if (plan_id !== undefined) {
      const { rows: planRows } = await req.db.query(
        `SELECT id, name, badge FROM subscription_plans WHERE id = $1`,
        [plan_id],
      );
      if (!planRows.length)
        return res.status(404).json({ error: "plan not found" });
      params.push(plan_id);
      fields.push(`plan_id = $${params.length}`);
      await req.db.query(
        `UPDATE users SET subscription_plan = $1, subscription_badge = $2 WHERE id = $3`,
        [planRows[0].name, planRows[0].badge, sub.user_id],
      );
    }
    if (current_period_end !== undefined) {
      params.push(new Date(current_period_end));
      fields.push(`current_period_end = $${params.length}`);
    }
    if (cancel_at_period_end !== undefined) {
      params.push(cancel_at_period_end);
      fields.push(`cancel_at_period_end = $${params.length}`);
    }
    if (auto_renew !== undefined) {
      params.push(auto_renew);
      fields.push(`auto_renew = $${params.length}`);
    }

    params.push(id);

    const { rows } = await req.db.query(
      `UPDATE subscriptions SET ${fields.join(", ")}
       WHERE id = $${params.length}
       RETURNING *`,
      params,
    );

    if (status === "cancelled") {
      await req.db.query(
        `UPDATE users SET subscription_plan = 'free', subscription_badge = null WHERE id = $1`,
        [sub.user_id],
      );
      const { safeDel } = await import("../config/redis.js");
      await safeDel(`user:${sub.user_id}`);
    }

    if (status && status !== sub.status) {
      await req.db.query(
        `INSERT INTO notifications
           (user_id, type, title, body, priority, action_url, channel)
         VALUES ($1,'system_announcement',$2,$3,'high','/settings/subscription','in_app')`,
        [
          sub.user_id,
          `Subscription ${status}`,
          `Your subscription has been updated to ${status} by an administrator.${notes ? ` Note: ${notes}` : ""}`,
        ],
      );
    }

    return res.json({
      message: "Subscription updated",
      subscription: rows[0],
    });
  } catch (err) {
    console.error("[subscriptions/adminUpdateSubscription]", err);
    return res.status(500).json({ error: "internal server error" });
  }
};
