// server.js – Flutterwave only (unified webhook)
import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import pool from "./src/config/database.js";
import redis from "./src/config/redis.js";

// ── Webhook controllers ─────────────────────────────────────────────
// We now import only the dispatcher
import { unifiedWebhook } from "./src/controllers/webhookDispatcher.js";

// ── Route imports (unchanged) ──────────────────────────────────────
import authRoutes from "./src/routes/auth.js";
import maidsRoutes from "./src/routes/maids.js";
import bookingsRoutes from "./src/routes/bookings.js";
import paymentsRoutes from "./src/routes/payments.js";
import adminRoutes from "./src/routes/admin.js";
import leadsRoutes from "./src/routes/leads.js";
import customerSupportRoutes from "./src/routes/customer-support-tickets.routes.js";
import maidSupportRoutes from "./src/routes/maid-support-tickets.routes.js";
import chatRoutes from "./src/routes/chat.routes.js";
import supportChatRouter from "./src/routes/customer-admin-livechat.routes.js";
import maidSupportChatRouter from "./src/routes/maid-admin-livechat.routes.js";
import settingsRoutes from "./src/routes/settings.routes.js";
import notificationsRoutes from "./src/routes/notifications.routes.js";
import withdrawalsRoutes from "./src/routes/withdrawals.routes.js";
import subscriptionsRoutes from "./src/routes/subscriptions.routes.js";
import earningsRouter from "./src/routes/earnings.routes.js";
import walletRouter from "./src/routes/wallet.routes.js";
import cleanerTrainingRoutes from "./src/routes/cleanerTraining.routes.js";
import housekeeperTrainingRoutes from "./src/routes/housekeeperTraining.routes.js";
import caregiverTrainingRoutes from "./src/routes/caregiverTraining.routes.js";
import domesticCertificationRoutes from "./src/routes/domesticCertification.routes.js";
import contactRoutes from "./src/routes/contact.routes.js";
import maidApplicationRoutes from "./src/routes/maidApplication.routes.js";
import foundationRoutes from "./src/routes/foundation.routes.js";
import giftCertificateRoutes from "./src/routes/giftCertificate.routes.js";
import shelterRoutes from "./src/routes/shelter.routes.js";
import userRoutes from "./src/routes/users.js";


import { transporter } from "./src/utils/mailer.js";

transporter.verify((error, success) => {
  if (error) {
    console.error("❌ SMTP connection failed:", error.message);
  } else {
    console.log("✅ SMTP server ready — emails will send");
  }
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 8080;

// ── CORS ──────────────────────────────────────────────────────────────
const allowedOrigins = [
  "http://localhost:5173",
  "http://localhost:3000",
  "http://localhost:8080",
  "http://127.0.0.1:5173",
  "http://127.0.0.1:3000",
  "http://142.93.13.254:5173",
  "http://142.93.13.254:3000",
  "https://deusizisparkle.com",
  "https://www.deusizisparkle.com",
'https://api.deusizisparkle.com',
  process.env.CORS_ORIGIN,
].filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error(`CORS blocked: ${origin}`));
      }
    },
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  }),
);

// ── Webhook route (raw body) MUST come BEFORE express.json() ─────────
app.post(
  "/api/webhook/flutterwave", // SINGLE ENDPOINT
  express.raw({ type: "application/json" }),
  unifiedWebhook,
);

// ── Body parsers ──────────────────────────────────────────────────────
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// ── Attach DB + Redis to every request ───────────────────────────────
app.use((req, _res, next) => {
  req.db = pool;
  req.redis = redis;
  next();
});

// ── Static files ──────────────────────────────────────────────────────
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

// ── API Routes ────────────────────────────────────────────────────────
app.use("/api/auth", authRoutes);
app.use("/api/maids", maidsRoutes);
app.use("/api/bookings", bookingsRoutes);
app.use("/api/payments", paymentsRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/leads", leadsRoutes);
app.use("/api/customer-support", customerSupportRoutes);
app.use("/api/maid-support", maidSupportRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/support-chat", supportChatRouter);
app.use("/api/maid-support-chat", maidSupportChatRouter);
app.use("/api/settings", settingsRoutes);
app.use("/api/notifications", notificationsRoutes);
app.use("/api/withdrawals", withdrawalsRoutes);
app.use("/api/subscriptions", subscriptionsRoutes);
app.use("/api/earnings", earningsRouter);
app.use("/api/wallet", walletRouter);
app.use("/api/cleaner-training", cleanerTrainingRoutes);
app.use("/api/housekeeper-training", housekeeperTrainingRoutes);
app.use("/api/caregiver-training", caregiverTrainingRoutes);
app.use("/api/domestic-certification", domesticCertificationRoutes);
app.use("/api/contact", contactRoutes);
app.use("/api/maid-application", maidApplicationRoutes);
app.use("/api/foundation", foundationRoutes);
app.use("/api/gift-certificates", giftCertificateRoutes);
app.use("/api/shelter", shelterRoutes);
app.use("/api/users", userRoutes);
// Serve the video call HTML
app.get("/video-call", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "video-call.html"));
});

// ── Health check ──────────────────────────────────────────────────────
app.get("/health", async (_req, res) => {
  const status = { postgres: "ok", redis: "ok" };

  try {
    await pool.query("SELECT 1");
  } catch (e) {
    status.postgres = e.message;
  }

  try {
    await redis.ping().catch(() => {
      throw new Error("unavailable");
    });
  } catch (e) {
    status.redis = e.message;
  }

  const healthy = status.postgres === "ok" && status.redis === "ok";
  return res.status(healthy ? 200 : 503).json({
    status: healthy ? "healthy" : "degraded",
    version: process.env.npm_package_version || "1.0.0",
    env: process.env.NODE_ENV || "development",
    ...status,
  });
});

// ── 404 ───────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: "route not found" });
});

// ── Global error handler ──────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error("[error]", err);
  res.status(err.status || 500).json({
    error:
      process.env.NODE_ENV === "production"
        ? "internal server error"
        : err.message,
  });
});

// ── Start ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✓ Deusizi Sparkle backend running on port ${PORT}`);
  console.log(`✓ Environment: ${process.env.NODE_ENV || "development"}`);
  console.log(`✓ CORS origins: ${allowedOrigins.join(", ")}`);
  console.log(`\n📍 API base: http://localhost:${PORT}/api`);
  console.log(`❤️  Health:   http://localhost:${PORT}/health`);
  console.log(
    `🧹 Cleaner Training: http://localhost:${PORT}/api/cleaner-training`,
  );
  console.log(
    `🏠 Housekeeper Training: http://localhost:${PORT}/api/housekeeper-training`,
  );
  console.log(
    `👶 Caregiver Training: http://localhost:${PORT}/api/caregiver-training`,
  );
  console.log(
    `📋 Domestic Certification: http://localhost:${PORT}/api/domestic-certification`,
  );
  console.log(`📧 Contact: http://localhost:${PORT}/api/contact`);
  console.log(
    `👩‍💼 Maid Application: http://localhost:${PORT}/api/maid-application`,
  );
  console.log(`💚 Foundation: http://localhost:${PORT}/api/foundation`);
  console.log(
    `🔗 Unified Webhook: http://localhost:${PORT}/api/webhook/flutterwave`,
  );
});

export { pool, redis };
